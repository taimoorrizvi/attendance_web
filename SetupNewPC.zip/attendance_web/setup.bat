@echo off
REM ============================================================
REM  One-time setup: creates venv + installs packages
REM ============================================================
cd /d %~dp0
if not exist venv (
    echo Creating virtual environment...
    python -m venv venv
)
call venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt

REM GPU: remove the CPU-only package (it hides the CUDA provider) and pull CUDA/cuDNN DLLs
pip uninstall -y onnxruntime
pip install "onnxruntime-gpu[cuda,cudnn]"

if not exist .env copy .env.example .env
echo.
echo ============================================================
echo  Setup done.
echo  1) Edit .env  (admin password, email app password, cameras)
echo  2) Import old data:  venv\Scripts\python tools\migrate_old.py "D:\AttendenceSystem"
echo  3) Start:            start.bat
echo ============================================================
pause
