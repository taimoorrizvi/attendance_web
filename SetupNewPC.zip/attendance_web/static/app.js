// ============================================================
//  Admin panel - vanilla JS, no build step
// ============================================================
const $ = id => document.getElementById(id);
const today = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 10); };
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function toast(msg, ms = 3000) {
  const t = $('toast'); t.textContent = msg; t.style.display = 'block';
  clearTimeout(t._h); t._h = setTimeout(() => t.style.display = 'none', ms);
}

async function api(url, opts = {}) {
  const res = await fetch(url, opts);
  if (!res.ok) {
    let msg = res.statusText;
    try { msg = (await res.json()).detail || msg; } catch (e) {}
    throw new Error(msg);
  }
  const ct = res.headers.get('content-type') || '';
  return ct.includes('json') ? res.json() : res;
}

function table(rows, cols, opts = {}) {
  if (!rows.length) return '<p class="hint">No data</p>';
  const head = cols.map(c => `<th>${esc(c.label || c)}</th>`).join('');
  const body = rows.map(r => '<tr>' + cols.map(c => {
    const key = c.key || c;
    const val = c.render ? c.render(r) : esc(r[key]);
    return `<td>${val}</td>`;
  }).join('') + '</tr>').join('');
  return `<table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>`;
}

// ------------------------------------------------------------ tabs
document.querySelectorAll('nav.tabs button').forEach(b => b.onclick = () => {
  document.querySelectorAll('nav.tabs button').forEach(x => x.classList.toggle('active', x === b));
  document.querySelectorAll('.section').forEach(s => s.classList.toggle('active', s.id === b.dataset.tab));
  const loaders = { dashboard: loadDashboard, attendance: loadAttendance, employees: loadEmployees,
                    enroll: loadFaces, holidays: loadHolidays, cameras: loadCameras };
  if (loaders[b.dataset.tab]) loaders[b.dataset.tab]();
  if (b.dataset.tab !== 'enroll') stopEnrollCam();
});

// ------------------------------------------------------------ dashboard
const dailyCols = [
  'Name', 'Department', 'Shift',
  { label: 'Check In', render: r => r['Check In'] ? esc(r['Check In']) : '<span class="red">-</span>' },
  { label: 'Check Out', render: r => r['Check Out'] ? esc(r['Check Out']) : '<span class="hint">-</span>' },
  'Worked Hrs',
  { label: 'Late Min', render: r => r['Late Min'] > 0 ? `<span class="red">${r['Late Min']}</span>` : '0' },
  { label: 'Early Out', render: r => r['Early Out Min'] > 0 ? `<span class="amber">${r['Early Out Min']}</span>` : '0' },
  'OT Hrs',
  { label: 'OT Amount', render: r => Number(r['OT Amount']).toLocaleString(undefined, { minimumFractionDigits: 2 }) },
  { label: 'Remarks', render: r => String(r.Remarks).includes('ABSENT') ? `<span class="red">${esc(r.Remarks)}</span>` : esc(r.Remarks) },
];

async function loadDashboard() {
  try {
    const s = await api('/api/status');
    $('appName').textContent = s.app_name;
    document.title = s.app_name + ' - Admin';
    if (s.camera_mode !== 'browser') $('camTab').style.display = '';
    const camText = Object.keys(s.cameras).length
      ? Object.entries(s.cameras).map(([k, v]) => `${k}: ${v ? 'OK' : 'DOWN'}`).join(' / ') : 'Browser kiosk';
    const cards = [
      ['Present today', `${s.present_today} / ${s.active_employees}`],
      ['Checked out', s.checked_out_today],
      ['Enrolled people', `${s.enrolled_people} (${s.templates} photos)`],
      ['AI engine', s.ai_provider],
      ['Cameras', camText],
      ['Windows', `IN ${s.windows.checkin}<br>OUT ${s.windows.checkout}${s.test_mode ? '<br><span class="amber">TEST MODE</span>' : ''}`],
      ['Notifications', `WhatsApp ${s.whatsapp_enabled ? 'ON' : 'OFF'}<br>Email ${s.email_configured ? 'ON' : '<span class="red">not set</span>'}`],
    ];
    $('statCards').innerHTML = cards.map(([l, v]) =>
      `<div class="card"><div class="label">${l}</div><div class="value" style="font-size:${String(v).length > 14 ? 15 : 26}px">${v}</div></div>`).join('');
    const rows = await api('/api/today');
    $('todayTable').innerHTML = table(rows, dailyCols);
    const ev = await api('/api/events?limit=30');
    $('eventsTable').innerHTML = table(ev, ['ts', 'name', 'action', 'result', 'source',
      { label: 'distance', render: r => r.distance == null ? '' : Number(r.distance).toFixed(3) }]);
  } catch (e) { toast('Error: ' + e.message); }
}

// ------------------------------------------------------------ attendance
async function loadAttendance() {
  if (!$('attDate').value) $('attDate').value = today();
  if (!$('corrDate').value) $('corrDate').value = today();
  const rows = await api('/api/today?date=' + $('attDate').value);
  $('attTable').innerHTML = table(rows, [...dailyCols, 'OT Rule',
    { label: '', render: r => `<button class="btn secondary" onclick="fillCorrection(${esc(JSON.stringify({ n: r.Name, d: r.Date, i: r['Check In'], o: r['Check Out'] }))})">Edit</button>` }]);
  await fillNameSelect();
}

async function fillNameSelect() {
  const emps = await api('/api/employees');
  $('corrName').innerHTML = emps.map(e => `<option>${esc(e.name)}</option>`).join('');
  $('empList').innerHTML = emps.map(e => `<option value="${esc(e.name)}">`).join('');
}

function fillCorrection(x) {
  $('corrName').value = x.n; $('corrDate').value = x.d; $('corrIn').value = x.i; $('corrOut').value = x.o;
  $('corrName').scrollIntoView({ behavior: 'smooth' });
}

async function saveCorrection() {
  try {
    await api('/api/attendance', { method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: $('corrName').value, date: $('corrDate').value, checkin: $('corrIn').value, checkout: $('corrOut').value }) });
    toast('Saved'); $('attDate').value = $('corrDate').value; loadAttendance();
  } catch (e) { toast('Error: ' + e.message); }
}

async function deleteCorrection() {
  if (!confirm('Delete this attendance record?')) return;
  await api(`/api/attendance?name=${encodeURIComponent($('corrName').value)}&date=${$('corrDate').value}`, { method: 'DELETE' });
  toast('Deleted'); loadAttendance();
}

// ------------------------------------------------------------ employees
async function loadEmployees() {
  const shifts = await api('/api/shifts');
  $('empShift').innerHTML = shifts.map(s => `<option value="${s.name}">${s.name} (${s.start}-${s.end})</option>`).join('');
  const emps = await api('/api/employees');
  $('empTable').innerHTML = table(emps, [
    { label: 'Name', key: 'name' }, { label: 'ID', key: 'employee_id' }, { label: 'Department', key: 'department' },
    { label: 'Designation', key: 'designation' },
    { label: 'Salary', render: r => Number(r.basic_salary).toLocaleString() }, { label: 'Shift', key: 'shift' },
    { label: 'WhatsApp', render: r => r.whatsapp ? esc(r.whatsapp) : '<span class="red">missing</span>' },
    { label: 'Photos', render: r => r.photos ? `<span class="badge ok">${r.photos}</span>` : '<span class="badge bad">0</span>' },
    { label: 'Active', render: r => r.active ? 'Yes' : '<span class="hint">No</span>' },
    { label: '', render: r => `<button class="btn secondary" onclick="editEmployee(${esc(JSON.stringify(r))})">Edit</button>
                               <button class="btn danger" onclick="deleteEmployee(${esc(JSON.stringify(r.name))})">Delete</button>` },
  ]);
}

function editEmployee(e) {
  $('empName').value = e.name; $('empId').value = e.employee_id; $('empDept').value = e.department;
  $('empDesig').value = e.designation; $('empSalary').value = e.basic_salary; $('empShift').value = e.shift;
  $('empPhone').value = e.whatsapp; $('empActive').value = e.active ? 'true' : 'false';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function clearEmployeeForm() {
  ['empName', 'empId', 'empDesig', 'empSalary', 'empPhone'].forEach(id => $(id).value = '');
  $('empDept').value = ''; $('empShift').value = 'GENERAL'; $('empActive').value = 'true';
}

async function saveEmployee() {
  try {
    await api('/api/employees', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: $('empName').value, employee_id: $('empId').value, department: $('empDept').value,
        designation: $('empDesig').value, basic_salary: Number($('empSalary').value || 0), shift: $('empShift').value,
        whatsapp: $('empPhone').value, active: $('empActive').value === 'true' }) });
    toast('Employee saved'); clearEmployeeForm(); loadEmployees();
  } catch (e) { toast('Error: ' + e.message); }
}

async function deleteEmployee(name) {
  if (!confirm(`Delete ${name}?`)) return;
  const photos = confirm('Also delete face photos? (OK = yes, Cancel = keep photos)');
  await api(`/api/employees/${encodeURIComponent(name)}?delete_photos=${photos}`, { method: 'DELETE' });
  toast('Deleted'); loadEmployees();
}

// ------------------------------------------------------------ enrollment
let enrollStream = null;
let captures = [];
const POSES = ['Straight', 'Slight left', 'Slight right', 'Slight up', 'Slight down', 'Straight / normal'];

async function startEnrollCam() {
  try {
    stopEnrollCam();
    const id = $('enrollCam').value;
    enrollStream = await navigator.mediaDevices.getUserMedia({
      video: id ? { deviceId: { exact: id }, width: 1280, height: 720 } : { width: 1280, height: 720 } });
    $('enrollVideo').srcObject = enrollStream;
    $('captureBtn').disabled = false;
    const devices = (await navigator.mediaDevices.enumerateDevices()).filter(d => d.kind === 'videoinput');
    const current = $('enrollCam').value;
    $('enrollCam').innerHTML = devices.map((d, i) => `<option value="${d.deviceId}">${esc(d.label || 'Camera ' + (i + 1))}</option>`).join('');
    if (current) $('enrollCam').value = current;
    updateCaptureCount();
  } catch (e) {
    toast('Camera error: ' + e.message + ' (use https:// or localhost)', 6000);
  }
}

function stopEnrollCam() {
  if (enrollStream) enrollStream.getTracks().forEach(t => t.stop());
  enrollStream = null;
  if ($('captureBtn')) $('captureBtn').disabled = true;
}

function updateCaptureCount() {
  const n = captures.length;
  $('captureCount').textContent = n < POSES.length ? `${n}/${POSES.length} - next: ${POSES[n]}` : `${n} photos ready`;
  $('uploadBtn').disabled = n === 0;
}

async function capturePhoto() {
  const v = $('enrollVideo');
  if (!v.videoWidth) return;
  const c = document.createElement('canvas');
  c.width = v.videoWidth; c.height = v.videoHeight;
  c.getContext('2d').drawImage(v, 0, 0);
  const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', 0.95));
  captures.push(blob);
  const img = document.createElement('img'); img.src = URL.createObjectURL(blob);
  $('thumbs').appendChild(img);
  updateCaptureCount();
}

function resetCaptures() { captures = []; $('thumbs').innerHTML = ''; $('enrollFiles').value = ''; updateCaptureCount(); }

$('enrollFiles').onchange = e => {
  for (const f of e.target.files) {
    captures.push(f);
    const img = document.createElement('img'); img.src = URL.createObjectURL(f); $('thumbs').appendChild(img);
  }
  updateCaptureCount();
};

document.addEventListener('keydown', e => {
  if (e.code === 'Space' && $('enroll').classList.contains('active') && enrollStream && document.activeElement.tagName !== 'INPUT') {
    e.preventDefault(); capturePhoto();
  }
});

async function uploadEnrollment() {
  const name = $('enrollName').value.trim().toUpperCase();
  if (!name) return toast('Enter a name first');
  const fd = new FormData();
  fd.append('name', name);
  captures.forEach((b, i) => fd.append('images', b, `${i}.jpg`));
  $('uploadBtn').disabled = true; toast('Processing faces...');
  try {
    const r = await api('/api/enroll', { method: 'POST', body: fd });
    toast(`${r.name}: ${r.saved.length} saved, ${r.rejected} rejected (no face found)`, 6000);
    resetCaptures(); loadFaces();
  } catch (e) { toast('Error: ' + e.message); }
  finally { updateCaptureCount(); }
}

async function loadFaces() {
  await fillNameSelect();
  const people = await api('/api/faces');
  const rows = Object.entries(people).map(([name, files]) => ({ name, files }));
  $('facesTable').innerHTML = table(rows, [
    { label: 'Name', key: 'name' }, { label: 'Photos', render: r => r.files.length },
    { label: 'Preview', render: r => r.files.slice(0, 6).map(f =>
        `<img src="/api/faces/image/${encodeURIComponent(f)}" style="width:56px;height:42px;object-fit:cover;border-radius:4px;margin-right:4px">`).join('') },
  ]);
}

// ------------------------------------------------------------ holidays
async function loadHolidays() {
  const rows = await api('/api/holidays');
  $('holTable').innerHTML = table(rows, ['date', 'description',
    { label: '', render: r => `<button class="btn danger" onclick="deleteHoliday('${r.date}')">Delete</button>` }]);
}
async function addHoliday() {
  try {
    await api('/api/holidays', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ date: $('holDate').value, description: $('holDesc').value || 'Public Holiday' }) });
    $('holDesc').value = ''; loadHolidays();
  } catch (e) { toast('Error: ' + e.message); }
}
async function deleteHoliday(d) { await api('/api/holidays/' + d, { method: 'DELETE' }); loadHolidays(); }

// ------------------------------------------------------------ reports
function download(kind, format) {
  const q = kind === 'daily' ? `date=${$('repDate').value || today()}` : `month=${$('repMonth').value || today().slice(0, 7)}`;
  window.location = `/api/reports/${kind}?${q}&format=${format}`;
}
async function emailNow() {
  try { await api('/api/reports/email?date=' + ($('repDate').value || today()), { method: 'POST' }); toast('Email sent'); }
  catch (e) { toast('Error: ' + e.message); }
}
async function previewMonthly() {
  const rows = await api(`/api/reports/monthly?month=${$('repMonth').value || today().slice(0, 7)}&format=json`);
  $('monthTable').innerHTML = table(rows, ['Name', 'Department', 'Working Days', 'Present Days',
    { label: 'Absent Days', render: r => r['Absent Days'] > 0 ? `<span class="red">${r['Absent Days']}</span>` : '0' },
    'Worked Hrs', 'OT Hrs', { label: 'OT Amount', render: r => Number(r['OT Amount']).toLocaleString() }, 'Late Min']);
}

// ------------------------------------------------------------ cctv
function loadCameras() {
  $('camIn').src = '/api/stream/IN?t=' + Date.now();
  $('camOut').src = '/api/stream/OUT?t=' + Date.now();
}

// ------------------------------------------------------------ init
$('repDate').value = today();
$('repMonth').value = today().slice(0, 7);
loadDashboard();
setInterval(() => { if ($('dashboard').classList.contains('active')) loadDashboard(); }, 10000);
