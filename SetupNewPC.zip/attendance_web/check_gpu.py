# Quick check: python check_gpu.py
import onnxruntime as ort
print("onnxruntime", ort.__version__)
print("providers  ", ort.get_available_providers())
print("GPU OK" if "CUDAExecutionProvider" in ort.get_available_providers()
      else "GPU NOT AVAILABLE - run: pip uninstall -y onnxruntime  then  pip install onnxruntime-gpu[cuda,cudnn]")
