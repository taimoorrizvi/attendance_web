# ============================================================
#  CCTV RTSP MODE - IN / OUT cameras processed on the server.
#  Live view is available in the browser as MJPEG.
# ============================================================
import os
import threading
import time
from datetime import datetime

import cv2

from . import config
from .attendance import process_checkin, process_checkout
from .face_engine import engine, tracker
from .logger import logger

os.environ.setdefault(
    "OPENCV_FFMPEG_CAPTURE_OPTIONS",
    "rtsp_transport;tcp|fflags;nobuffer|flags;low_delay|max_delay;500000",
)


class RTSPCamera:
    def __init__(self, url, action):
        self.url, self.action = url, action
        self.cap = None
        self.frame = None
        self.last_frame_time = 0
        self.results = []
        self.jpeg = None
        self.lock = threading.Lock()
        self.running = True
        threading.Thread(target=self._reader, daemon=True, name=f"rtsp-{action}").start()
        threading.Thread(target=self._ai_loop, daemon=True, name=f"ai-{action}").start()

    @property
    def online(self):
        return time.time() - self.last_frame_time < config.CAMERA_STALE_SECONDS

    def _reader(self):
        while self.running:
            if self.cap is None or not self.cap.isOpened():
                logger.info(f"[{self.action}] Connecting RTSP...")
                self.cap = cv2.VideoCapture(self.url, cv2.CAP_FFMPEG)
                self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
                if not self.cap.isOpened():
                    time.sleep(config.CAMERA_RECONNECT_DELAY)
                    continue
                logger.info(f"[{self.action}] RTSP connected.")
            ok, frame = self.cap.read()
            if ok and frame is not None:
                with self.lock:
                    self.frame = frame
                    self.last_frame_time = time.time()
            else:
                logger.warning(f"[{self.action}] Frame lost - reconnecting")
                self.cap.release()
                self.cap = None
                time.sleep(1)

    def _ai_loop(self):
        while self.running:
            start = time.time()
            with self.lock:
                frame = None if self.frame is None or not self.online else self.frame.copy()
            if frame is None:
                time.sleep(0.1)
                continue
            h, w = frame.shape[:2]
            scale = min(1.0, config.AI_MAX_WIDTH / w)
            ai_frame = cv2.resize(frame, (int(w * scale), int(h * scale))) if scale < 1 else frame
            results = engine.recognize(ai_frame)
            for r in results:
                r["bbox"] = [int(v / scale) for v in r["bbox"]]
                if r["matched"] and tracker.should_fire(f"rtsp-{self.action}", self.action,
                                                        r["name"], r["distance"]):
                    fn = process_checkin if self.action == "IN" else process_checkout
                    fn(r["name"], source=f"CCTV-{self.action}", distance=r["distance"])
            self.results = results
            self.jpeg = self._annotate(frame, results)
            time.sleep(max(0.0, config.AI_INTERVAL - (time.time() - start)))

    def _annotate(self, frame, results):
        disp = frame.copy()
        for r in results:
            x1, y1, x2, y2 = r["bbox"]
            color = (0, 200, 0) if r["matched"] else (0, 0, 255)
            label = f"{r['name']} {r['distance']:.2f}" if r["matched"] else "UNKNOWN"
            cv2.rectangle(disp, (x1, y1), (x2, y2), color, 2)
            cv2.putText(disp, label, (x1, max(20, y1 - 8)), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
        cv2.putText(disp, f"{self.action} CAMERA  {datetime.now():%Y-%m-%d %H:%M:%S}", (20, 35),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        ok, buf = cv2.imencode(".jpg", disp, [cv2.IMWRITE_JPEG_QUALITY, 70])
        return buf.tobytes() if ok else None

    def mjpeg(self):
        while True:
            if self.jpeg:
                yield b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + self.jpeg + b"\r\n"
            time.sleep(0.15)


cameras = {}


def start_rtsp_cameras():
    if not config.IN_CAMERA_URL or not config.OUT_CAMERA_URL:
        logger.error("CAMERA_MODE includes rtsp but IN_CAMERA_URL / OUT_CAMERA_URL are empty in .env")
        return
    cameras["IN"] = RTSPCamera(config.IN_CAMERA_URL, "IN")
    cameras["OUT"] = RTSPCamera(config.OUT_CAMERA_URL, "OUT")
