# ============================================================
#  NIZAM ENERGY - AI FACE ATTENDANCE (WEB) - CONFIGURATION
#  All values can be overridden in the .env file.
# ============================================================
import os
from datetime import time as dtime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

try:
    from dotenv import load_dotenv
    load_dotenv(BASE_DIR / ".env")
except ImportError:
    pass


def _str(name, default=""):
    return os.getenv(name, default).strip()


def _int(name, default):
    try:
        return int(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


def _float(name, default):
    try:
        return float(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


def _bool(name, default=False):
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in ("1", "true", "yes", "on")


def _time(name, default):
    value = _str(name, default)
    hh, mm = value.split(":")[:2]
    return dtime(int(hh), int(mm))


# ------------------------------------------------------------
# App / server
# ------------------------------------------------------------
APP_NAME = _str("APP_NAME", "Nizam Energy AI Attendance")
HOST = _str("HOST", "0.0.0.0")
PORT = _int("PORT", 8000)
SSL_CERTFILE = _str("SSL_CERTFILE")
SSL_KEYFILE = _str("SSL_KEYFILE")

ADMIN_USER = _str("ADMIN_USER", "admin")
ADMIN_PASSWORD = _str("ADMIN_PASSWORD", "admin123")

# Optional shared key for kiosk devices. Empty = kiosk is open on the LAN.
KIOSK_KEY = _str("KIOSK_KEY")

# ------------------------------------------------------------
# Storage
# ------------------------------------------------------------
DATA_DIR = Path(_str("DATA_DIR", str(BASE_DIR / "data")))
DB_FILE = DATA_DIR / "attendance.db"
KNOWN_FACES_DIR = DATA_DIR / "known_faces"
EMBED_CACHE_FILE = DATA_DIR / "embeddings_cache.pkl"
LOG_DIR = DATA_DIR / "logs"
LOG_FILE = LOG_DIR / "attendance_system.log"

for _d in (DATA_DIR, KNOWN_FACES_DIR, LOG_DIR):
    _d.mkdir(parents=True, exist_ok=True)

# ------------------------------------------------------------
# Cameras
#   browser = webcam of any PC/tablet that opens /kiosk
#   rtsp    = two CCTV cameras processed on the server
#   both    = run both
# ------------------------------------------------------------
CAMERA_MODE = _str("CAMERA_MODE", "browser").lower()
IN_CAMERA_URL = _str("IN_CAMERA_URL")
OUT_CAMERA_URL = _str("OUT_CAMERA_URL")
CAMERA_RECONNECT_DELAY = 2
CAMERA_STALE_SECONDS = 5
AI_MAX_WIDTH = 960
AI_INTERVAL = 0.20

# ------------------------------------------------------------
# Face AI
# ------------------------------------------------------------
USE_GPU = _bool("USE_GPU", True)
MODEL_NAME = _str("MODEL_NAME", "buffalo_l")
DET_SIZE = (640, 640)
DETECTION_THRESHOLD = _float("DETECTION_THRESHOLD", 0.30)
MATCH_THRESHOLD = _float("MATCH_THRESHOLD", 0.42)
VERY_STRONG_THRESHOLD = _float("VERY_STRONG_THRESHOLD", 0.32)
CONFIRMATIONS_REQUIRED = _int("CONFIRMATIONS_REQUIRED", 2)
RECOGNITION_COOLDOWN = _float("RECOGNITION_COOLDOWN", 2.0)
ENROLL_PHOTOS = _int("ENROLL_PHOTOS", 6)

# ------------------------------------------------------------
# Attendance windows
# ------------------------------------------------------------
TEST_MODE = _bool("TEST_MODE", False)   # True = 24h windows (demo)
if TEST_MODE:
    CHECKIN_START, CHECKIN_END = dtime(0, 0), dtime(23, 59, 59)
    CHECKOUT_START, CHECKOUT_END = dtime(0, 0), dtime(23, 59, 59)
else:
    CHECKIN_START = _time("CHECKIN_START", "08:00")
    CHECKIN_END = _time("CHECKIN_END", "18:00")
    CHECKOUT_START = _time("CHECKOUT_START", "08:00")
    CHECKOUT_END = _time("CHECKOUT_END", "22:00")
ALLOW_EARLY_CHECKOUT = _bool("ALLOW_EARLY_CHECKOUT", False)

# The old script overwrote check-out every 2 seconds while a person stood in
# front of the camera (and sent a WhatsApp each time). Now check-out is only
# re-written if the previous one is older than this many seconds.
CHECKOUT_UPDATE_COOLDOWN = _int("CHECKOUT_UPDATE_COOLDOWN", 300)

# ------------------------------------------------------------
# Notifications
# ------------------------------------------------------------
WHATSAPP_ENABLED = _bool("WHATSAPP_ENABLED", True)
WHATSAPP_BRIDGE_URL = _str("WHATSAPP_BRIDGE_URL", "http://localhost:3000/send-message")
SEND_CHECKOUT_NOTIFICATIONS = _bool("SEND_CHECKOUT_NOTIFICATIONS", True)
MAX_NOTIFICATION_RETRIES = 5
RETRY_DELAYS = [2, 5, 15, 30, 60]

SMTP_HOST = _str("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = _int("SMTP_PORT", 465)
SENDER_EMAIL = _str("SENDER_EMAIL")
SENDER_PASSWORD = _str("SENDER_PASSWORD")          # Gmail App Password
RECEIVER_EMAIL = _str("RECEIVER_EMAIL")            # comma separated allowed
DAILY_REPORT_ENABLED = _bool("DAILY_REPORT_ENABLED", True)
DAILY_REPORT_HOUR = _int("DAILY_REPORT_HOUR", 22)

# ------------------------------------------------------------
# Payroll / OT
# ------------------------------------------------------------
MONTHLY_WORKING_DAYS = _int("MONTHLY_WORKING_DAYS", 26)
HOLIDAY_OT_MULTIPLIER = _float("HOLIDAY_OT_MULTIPLIER", 1.75)
NEXT_DAY_LATE_GRACE_MINUTES = 120

SHIFT_DEFINITIONS = {
    "PRODUCTION DAY": {"start": dtime(8, 0), "end": dtime(16, 0), "hours": 8},
    "PRODUCTION EVENING": {"start": dtime(15, 0), "end": dtime(23, 0), "hours": 8},
    "PRODUCTION NIGHT": {"start": dtime(20, 0), "end": dtime(4, 0), "hours": 8},
    "LOGISTICS DAY": {"start": dtime(8, 0), "end": dtime(20, 0), "hours": 12},
    "LOGISTICS NIGHT": {"start": dtime(20, 0), "end": dtime(8, 0), "hours": 12},
    "GENERAL": {"start": dtime(9, 0), "end": dtime(17, 0), "hours": 8},
    "SATURDAY": {"start": dtime(10, 0), "end": dtime(16, 0), "hours": 6},
}
