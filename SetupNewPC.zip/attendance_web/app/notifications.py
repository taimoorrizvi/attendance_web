# ============================================================
#  WhatsApp (local bridge) + Email + 10 PM daily report
# ============================================================
import queue
import smtplib
import threading
import time
import traceback
from datetime import datetime
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import requests

from . import config, db, payroll
from .logger import logger

notification_queue = queue.Queue(maxsize=1000)


def queue_notification(name, date_str, time_str, status):
    if not config.WHATSAPP_ENABLED:
        return
    try:
        notification_queue.put_nowait(
            {"name": name, "date": date_str, "time": time_str, "status": status, "attempt": 0}
        )
    except queue.Full:
        logger.error("Notification queue is full.")


def send_whatsapp(name, status, time_str):
    emp = db.get_employee(name) or {}
    phone = emp.get("whatsapp", "")
    if not phone:
        logger.warning(f"No WhatsApp number: {name}")
        return True          # nothing to retry
    message = f"🏢 *NIZAM ENERGY*\n👤 *{name}*\n🕒 *{status}*: {time_str}"
    try:
        r = requests.post(config.WHATSAPP_BRIDGE_URL,
                          json={"phone": phone, "message": message}, timeout=5)
        if r.ok:
            logger.info(f"WhatsApp sent | {name} | {status}")
            return True
        logger.warning(f"WhatsApp HTTP {r.status_code}")
    except Exception as e:
        logger.warning(f"WhatsApp error | {name} | {e}")
    return False


def _notification_worker():
    logger.info("Notification worker started.")
    while True:
        item = notification_queue.get()
        try:
            if not send_whatsapp(item["name"], item["status"], item["time"]):
                if item["attempt"] < config.MAX_NOTIFICATION_RETRIES:
                    delay = config.RETRY_DELAYS[min(item["attempt"], len(config.RETRY_DELAYS) - 1)]
                    item["attempt"] += 1
                    logger.warning(f"Notification retry {item['attempt']} in {delay}s | {item['name']}")
                    # Re-queue later without blocking the worker
                    threading.Timer(delay, lambda it=item: notification_queue.put(it)).start()
        except Exception:
            logger.error(traceback.format_exc())
        finally:
            notification_queue.task_done()


# ------------------------------------------------------------
# Email
# ------------------------------------------------------------
def email_configured():
    return bool(config.SENDER_EMAIL and config.SENDER_PASSWORD and config.RECEIVER_EMAIL)


def send_daily_report_email(date_str=None):
    if not email_configured():
        logger.warning("Email not configured - set SENDER_EMAIL / SENDER_PASSWORD / RECEIVER_EMAIL in .env")
        return False
    date_str = date_str or datetime.now().strftime("%Y-%m-%d")
    try:
        df = payroll.build_daily(date_str)
        xlsx = payroll.to_xlsx_bytes({"Daily Payroll": df})
        csv_bytes = payroll.to_csv_bytes(df)

        receivers = [x.strip() for x in config.RECEIVER_EMAIL.split(",") if x.strip()]
        msg = MIMEMultipart()
        msg["From"] = config.SENDER_EMAIL
        msg["To"] = ", ".join(receivers)
        msg["Subject"] = f"Daily Attendance Report - {date_str}"
        present = int(((df["Check In"] != "") | (df["Check Out"] != "")).sum())
        body = (
            f"Daily Attendance Report\n\nDate: {date_str}\n"
            f"Employees: {len(df)} | Present: {present} | Absent: {len(df) - present}\n"
            f"Total OT Amount: PKR {df['OT Amount'].sum():,.2f}\n\n"
            "Late and early-out minutes are marked red in Excel.\n\nRegards,\nAI Attendance System"
        )
        msg.attach(MIMEText(body, "plain"))
        for filename, payload, maintype, subtype in (
            (f"Daily_Payroll_Summary_{date_str}.xlsx", xlsx, "application",
             "vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
            (f"Attendance_{date_str}.csv", csv_bytes, "text", "csv"),
        ):
            part = MIMEBase(maintype, subtype)
            part.set_payload(payload)
            encoders.encode_base64(part)
            part.add_header("Content-Disposition", f'attachment; filename="{filename}"')
            msg.attach(part)

        with smtplib.SMTP_SSL(config.SMTP_HOST, config.SMTP_PORT, timeout=20) as server:
            server.login(config.SENDER_EMAIL, config.SENDER_PASSWORD)
            server.send_message(msg)
        logger.info(f"Daily report email sent | {date_str}")
        return True
    except Exception as e:
        logger.error(f"Daily report email error | {e}")
        return False


def _daily_email_worker():
    last_sent = None
    logger.info(f"Daily email worker started. Report time: {config.DAILY_REPORT_HOUR}:00")
    while True:
        try:
            now = datetime.now()
            today = now.strftime("%Y-%m-%d")
            if now.hour >= config.DAILY_REPORT_HOUR and last_sent != today:
                if send_daily_report_email(today):
                    last_sent = today
                else:
                    time.sleep(300)     # do not hammer SMTP on failure
            time.sleep(20)
        except Exception:
            logger.error(traceback.format_exc())
            time.sleep(30)


def start_workers():
    threading.Thread(target=_notification_worker, daemon=True, name="notify").start()
    if config.DAILY_REPORT_ENABLED:
        threading.Thread(target=_daily_email_worker, daemon=True, name="daily-email").start()
