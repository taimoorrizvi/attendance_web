# ============================================================
#  FACE ENGINE - InsightFace ArcFace (buffalo_l)
#  GPU via onnxruntime-gpu when available, else CPU.
# ============================================================
import os
import pickle
import sys
import threading
import time

import cv2
import numpy as np

from . import config
from .logger import logger


def _setup_cuda_dlls():
    """Make pip-installed NVIDIA DLLs visible on Windows (same as the old script)."""
    if os.name != "nt":
        return
    nvidia = os.path.join(sys.prefix, "Lib", "site-packages", "nvidia")
    dirs = [os.path.join(nvidia, d, "bin") for d in
            ("cuda_runtime", "cublas", "cudnn", "cufft", "cuda_nvrtc", "curand")]
    dirs = [d for d in dirs if os.path.isdir(d)]
    for d in dirs:
        try:
            os.add_dll_directory(d)
        except Exception:
            pass
    if dirs:
        os.environ["PATH"] = ";".join(dirs) + ";" + os.environ.get("PATH", "")


class FaceEngine:
    def __init__(self):
        self.ai_lock = threading.Lock()
        self.data_lock = threading.RLock()
        self.app = None
        self.provider = "CPU"
        self.names = []
        self.files = []
        self.matrix = np.empty((0, 512), dtype=np.float32)

    # --------------------------------------------------------
    def load_model(self):
        if config.USE_GPU:
            _setup_cuda_dlls()
        import onnxruntime as ort
        from insightface.app import FaceAnalysis

        available = ort.get_available_providers()
        logger.info(f"ONNX Runtime {ort.__version__} | providers: {available}")
        use_cuda = config.USE_GPU and "CUDAExecutionProvider" in available
        providers = ["CUDAExecutionProvider", "CPUExecutionProvider"] if use_cuda else ["CPUExecutionProvider"]
        if config.USE_GPU and not use_cuda:
            logger.warning("USE_GPU=true but CUDAExecutionProvider is NOT available - running on CPU. "
                           "Install onnxruntime-gpu (and uninstall onnxruntime).")
        self.provider = "GPU (CUDA)" if use_cuda else "CPU"

        self.app = FaceAnalysis(name=config.MODEL_NAME, providers=providers,
                                allowed_modules=["detection", "recognition"])
        self.app.prepare(ctx_id=0 if use_cuda else -1, det_size=config.DET_SIZE,
                         det_thresh=config.DETECTION_THRESHOLD)
        logger.info(f"ArcFace engine ready on {self.provider}")

    # --------------------------------------------------------
    @staticmethod
    def name_from_file(filename):
        # BOOZAR_1.jpg -> BOOZAR ; "HASSAM HASSAN_3.jpg" -> HASSAM HASSAN
        stem = os.path.splitext(filename)[0].upper()
        if "_" in stem:
            base, _, suffix = stem.rpartition("_")
            if suffix.isdigit():
                return base
        return stem

    def _largest_face(self, image):
        with self.ai_lock:
            faces = self.app.get(image)
        if not faces:
            return None
        return max(faces, key=lambda f: (f.bbox[2] - f.bbox[0]) * (f.bbox[3] - f.bbox[1]))

    def embedding_for_image(self, image):
        face = self._largest_face(image)
        if face is None:
            return None
        emb = face.embedding.astype(np.float32)
        norm = np.linalg.norm(emb)
        return None if norm == 0 else emb / norm

    # --------------------------------------------------------
    def load_known_faces(self):
        """Loads all templates; uses a cache so restarts are fast."""
        cache = {}
        if config.EMBED_CACHE_FILE.exists():
            try:
                with open(config.EMBED_CACHE_FILE, "rb") as f:
                    cache = pickle.load(f)
            except Exception:
                cache = {}

        names, files, embs, new_cache = [], [], [], {}
        for filename in sorted(os.listdir(config.KNOWN_FACES_DIR)):
            if not filename.lower().endswith((".jpg", ".jpeg", ".png")):
                continue
            path = config.KNOWN_FACES_DIR / filename
            mtime = path.stat().st_mtime
            cached = cache.get(filename)
            if cached and cached[0] == mtime:
                emb = cached[1]
            else:
                image = cv2.imread(str(path))
                emb = self.embedding_for_image(image) if image is not None else None
                if emb is None:
                    logger.warning(f"No face found in template: {filename}")
                    continue
            new_cache[filename] = (mtime, emb)
            names.append(self.name_from_file(filename))
            files.append(filename)
            embs.append(emb)

        with open(config.EMBED_CACHE_FILE, "wb") as f:
            pickle.dump(new_cache, f)

        with self.data_lock:
            self.names, self.files = names, files
            self.matrix = np.asarray(embs, dtype=np.float32) if embs else np.empty((0, 512), np.float32)
        logger.info(f"Face templates loaded: {len(names)} images | {len(set(names))} people")

    def people(self):
        with self.data_lock:
            result = {}
            for n, f in zip(self.names, self.files):
                result.setdefault(n, []).append(f)
            return result

    # --------------------------------------------------------
    def enroll(self, name, images_bytes):
        """Saves images that contain a face. Returns (saved_files, rejected_count)."""
        name = name.strip().upper()
        existing = [f for f in os.listdir(config.KNOWN_FACES_DIR)
                    if self.name_from_file(f) == name]
        next_no = 1
        for f in existing:
            suffix = os.path.splitext(f)[0].rpartition("_")[2]
            if suffix.isdigit():
                next_no = max(next_no, int(suffix) + 1)

        saved, rejected = [], 0
        for raw in images_bytes:
            image = cv2.imdecode(np.frombuffer(raw, np.uint8), cv2.IMREAD_COLOR)
            if image is None or self.embedding_for_image(image) is None:
                rejected += 1
                continue
            filename = f"{name}_{next_no}.jpg"
            cv2.imwrite(str(config.KNOWN_FACES_DIR / filename), image, [cv2.IMWRITE_JPEG_QUALITY, 95])
            saved.append(filename)
            next_no += 1
        if saved:
            self.load_known_faces()
        return saved, rejected

    def delete_person(self, name):
        name = name.upper()
        removed = 0
        for f in os.listdir(config.KNOWN_FACES_DIR):
            if self.name_from_file(f) == name:
                os.remove(config.KNOWN_FACES_DIR / f)
                removed += 1
        self.load_known_faces()
        return removed

    # --------------------------------------------------------
    def recognize(self, frame):
        with self.data_lock:
            matrix, names = self.matrix, list(self.names)
        try:
            with self.ai_lock:
                faces = self.app.get(frame)
        except Exception as e:
            logger.warning(f"Face AI error: {e}")
            return []

        results = []
        for face in faces:
            emb = face.embedding.astype(np.float32)
            norm = np.linalg.norm(emb)
            if norm == 0:
                continue
            emb /= norm
            bbox = [int(v) for v in face.bbox]
            if len(names) == 0:
                results.append({"bbox": bbox, "name": "UNKNOWN", "distance": 1.0, "matched": False})
                continue
            distances = 1.0 - matrix @ emb
            idx = int(np.argmin(distances))
            distance = float(distances[idx])
            matched = distance < config.MATCH_THRESHOLD
            results.append({"bbox": bbox, "name": names[idx] if matched else "UNKNOWN",
                            "distance": round(distance, 3), "matched": matched})
        return results


engine = FaceEngine()


# ============================================================
#  Confirmation logic (same rules as the old handle_face)
# ============================================================
class RecognitionTracker:
    def __init__(self):
        self.lock = threading.Lock()
        self.confirm = {}        # (source, action, name) -> {"count", "last"}
        self.last_processed = {}  # (action, name) -> ts

    def should_fire(self, source, action, name, distance):
        now = time.time()
        with self.lock:
            key = (action, name)
            if now - self.last_processed.get(key, 0) < config.RECOGNITION_COOLDOWN:
                return False
            ckey = (source, action, name)
            if distance < config.VERY_STRONG_THRESHOLD:
                fire = True
            else:
                state = self.confirm.get(ckey)
                if state is None or now - state["last"] > 1.5:
                    self.confirm[ckey] = {"count": 1, "last": now}
                    fire = config.CONFIRMATIONS_REQUIRED <= 1
                else:
                    state["count"] += 1
                    state["last"] = now
                    fire = state["count"] >= config.CONFIRMATIONS_REQUIRED
            if fire:
                self.last_processed[key] = now
                self.confirm.pop(ckey, None)
            return fire


tracker = RecognitionTracker()
