# ============================================================
#  CHECK-IN / CHECK-OUT RULES
# ============================================================
from datetime import datetime

from . import config, db
from .logger import logger
from .notifications import queue_notification


def process_checkin(name, source="", distance=None):
    name = name.upper()
    now = datetime.now()
    today, time_str = now.strftime("%Y-%m-%d"), now.strftime("%H:%M:%S")

    if not (config.CHECKIN_START <= now.time() <= config.CHECKIN_END):
        db.log_event(name, "IN", "IGNORED_OUTSIDE_WINDOW", source, distance)
        return {"ok": False, "status": "outside_window", "message": f"{name}: check-in window closed"}

    with db.db_lock:
        row = db.get_attendance(name, today)
        if row and row["checkin"]:
            return {"ok": False, "status": "already", "time": row["checkin"],
                    "message": f"{name}: already checked in at {row['checkin']}"}
        with db.connect() as conn:
            if row:
                conn.execute("UPDATE attendance SET checkin=? WHERE name=? AND date=?",
                             (time_str, name, today))
            else:
                conn.execute("INSERT INTO attendance(name,date,checkin,checkout) VALUES(?,?,?,'')",
                             (name, today, time_str))

    db.log_event(name, "IN", "SAVED", source, distance)
    logger.info(f"CHECK-IN SAVED | {name} | {time_str} | {source}")
    queue_notification(name, today, time_str, "CHECK-IN")
    return {"ok": True, "status": "saved", "time": time_str, "message": f"Welcome {name} - checked in {time_str}"}


def process_checkout(name, source="", distance=None):
    name = name.upper()
    now = datetime.now()
    today, time_str = now.strftime("%Y-%m-%d"), now.strftime("%H:%M:%S")

    if not config.ALLOW_EARLY_CHECKOUT and not (config.CHECKOUT_START <= now.time() <= config.CHECKOUT_END):
        db.log_event(name, "OUT", "IGNORED_OUTSIDE_WINDOW", source, distance)
        return {"ok": False, "status": "outside_window", "message": f"{name}: check-out window closed"}

    with db.db_lock:
        row = db.get_attendance(name, today)
        if row and row["checkout"]:
            last = datetime.strptime(f"{today} {row['checkout']}", "%Y-%m-%d %H:%M:%S")
            if (now - last).total_seconds() < config.CHECKOUT_UPDATE_COOLDOWN:
                return {"ok": False, "status": "already", "time": row["checkout"],
                        "message": f"{name}: checked out at {row['checkout']}"}
        with db.connect() as conn:
            if row is None:
                conn.execute("INSERT INTO attendance(name,date,checkin,checkout) VALUES(?,?,'',?)",
                             (name, today, time_str))
            else:
                conn.execute("UPDATE attendance SET checkout=? WHERE name=? AND date=?",
                             (time_str, name, today))

    db.log_event(name, "OUT", "SAVED", source, distance)
    logger.info(f"CHECK-OUT SAVED | {name} | {time_str} | {source}")
    if config.SEND_CHECKOUT_NOTIFICATIONS:
        queue_notification(name, today, time_str, "CHECK-OUT")
    return {"ok": True, "status": "saved", "time": time_str, "message": f"Goodbye {name} - checked out {time_str}"}
