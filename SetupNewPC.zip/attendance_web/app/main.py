# ============================================================
#  NIZAM ENERGY - AI FACE ATTENDANCE - WEB APPLICATION
# ============================================================
import secrets
from contextlib import asynccontextmanager
from datetime import datetime
from typing import List, Optional

import cv2
import numpy as np
from fastapi import Depends, FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.responses import FileResponse, JSONResponse, Response, StreamingResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import cameras, config, db, payroll
from .attendance import process_checkin, process_checkout
from .face_engine import engine, tracker
from .logger import logger
from .notifications import email_configured, send_daily_report_email, start_workers

STATIC_DIR = config.BASE_DIR / "static"
security = HTTPBasic()


def require_admin(credentials: HTTPBasicCredentials = Depends(security)):
    ok_user = secrets.compare_digest(credentials.username, config.ADMIN_USER)
    ok_pass = secrets.compare_digest(credentials.password, config.ADMIN_PASSWORD)
    if not (ok_user and ok_pass):
        raise HTTPException(401, "Invalid credentials", headers={"WWW-Authenticate": "Basic"})
    return credentials.username


def require_kiosk(x_kiosk_key: Optional[str] = Header(default=None)):
    if config.KIOSK_KEY and x_kiosk_key != config.KIOSK_KEY:
        raise HTTPException(403, "Invalid kiosk key")


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("=" * 50)
    logger.info(f"{config.APP_NAME} - WEB VERSION")
    logger.info("=" * 50)
    if config.ADMIN_PASSWORD == "admin123":
        logger.warning("Default admin password in use - change ADMIN_PASSWORD in .env")
    db.init_db()
    engine.load_model()
    engine.load_known_faces()
    for name in engine.people():
        db.ensure_employee(name)
    start_workers()
    if config.CAMERA_MODE in ("rtsp", "both"):
        cameras.start_rtsp_cameras()
    yield


app = FastAPI(title=config.APP_NAME, lifespan=lifespan)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


# ------------------------------------------------------------
# Pages
# ------------------------------------------------------------
@app.get("/", include_in_schema=False)
def admin_page(_: str = Depends(require_admin)):
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/kiosk", include_in_schema=False)
def kiosk_page():
    return FileResponse(STATIC_DIR / "kiosk.html")


# ------------------------------------------------------------
# Kiosk: browser webcam frames -> recognition
# ------------------------------------------------------------
@app.post("/api/recognize", dependencies=[Depends(require_kiosk)])
def recognize(action: str = Form(...), source: str = Form("kiosk"), image: UploadFile = File(...)):
    action = action.upper()
    if action not in ("IN", "OUT"):
        raise HTTPException(400, "action must be IN or OUT")
    frame = cv2.imdecode(np.frombuffer(image.file.read(), np.uint8), cv2.IMREAD_COLOR)
    if frame is None:
        raise HTTPException(400, "Invalid image")

    results = engine.recognize(frame)
    events = []
    for r in results:
        if r["matched"] and tracker.should_fire(source, action, r["name"], r["distance"]):
            fn = process_checkin if action == "IN" else process_checkout
            outcome = fn(r["name"], source=f"KIOSK-{source}", distance=r["distance"])
            events.append({"name": r["name"], "action": action, **outcome})
    return {"faces": results, "events": events, "width": frame.shape[1], "height": frame.shape[0]}


@app.get("/api/kiosk/config")
def kiosk_config():
    suggested = "IN" if datetime.now().hour < 13 else "OUT"
    return {"app_name": config.APP_NAME, "suggested_action": suggested,
            "key_required": bool(config.KIOSK_KEY)}


# ------------------------------------------------------------
# Dashboard
# ------------------------------------------------------------
@app.get("/api/status", dependencies=[Depends(require_admin)])
def status():
    today = datetime.now().strftime("%Y-%m-%d")
    att = db.attendance_for_date(today)
    employees = db.list_employees(active_only=True)
    return {
        "app_name": config.APP_NAME,
        "now": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "ai_provider": engine.provider,
        "enrolled_people": len(engine.people()),
        "templates": len(engine.names),
        "active_employees": len(employees),
        "present_today": sum(1 for r in att if r["checkin"] or r["checkout"]),
        "checked_out_today": sum(1 for r in att if r["checkout"]),
        "camera_mode": config.CAMERA_MODE,
        "cameras": {k: c.online for k, c in cameras.cameras.items()},
        "email_configured": email_configured(),
        "whatsapp_enabled": config.WHATSAPP_ENABLED,
        "test_mode": config.TEST_MODE,
        "windows": {
            "checkin": f"{config.CHECKIN_START:%H:%M}-{config.CHECKIN_END:%H:%M}",
            "checkout": f"{config.CHECKOUT_START:%H:%M}-{config.CHECKOUT_END:%H:%M}",
        },
    }


@app.get("/api/today", dependencies=[Depends(require_admin)])
def today_sheet(date: Optional[str] = None):
    date = date or datetime.now().strftime("%Y-%m-%d")
    df = payroll.build_daily(date)
    return JSONResponse(df.fillna("").to_dict(orient="records"))


@app.get("/api/events", dependencies=[Depends(require_admin)])
def events(limit: int = 50):
    return db.recent_events(min(limit, 500))


# ------------------------------------------------------------
# Manual attendance correction
# ------------------------------------------------------------
class AttendanceIn(BaseModel):
    name: str
    date: str
    checkin: str = ""
    checkout: str = ""


def _valid_time(t):
    if not t:
        return ""
    t = t.strip()
    if len(t) == 5:
        t += ":00"
    datetime.strptime(t, "%H:%M:%S")
    return t


@app.put("/api/attendance")
def edit_attendance(body: AttendanceIn, user: str = Depends(require_admin)):
    try:
        datetime.strptime(body.date, "%Y-%m-%d")
        cin, cout = _valid_time(body.checkin), _valid_time(body.checkout)
    except ValueError:
        raise HTTPException(400, "Use YYYY-MM-DD and HH:MM or HH:MM:SS")
    db.set_attendance(body.name, body.date, cin, cout)
    db.log_event(body.name.upper(), "EDIT", f"MANUAL {cin}-{cout} on {body.date}", f"admin:{user}")
    return {"ok": True}


@app.delete("/api/attendance")
def remove_attendance(name: str, date: str, user: str = Depends(require_admin)):
    db.delete_attendance(name, date)
    db.log_event(name.upper(), "EDIT", f"DELETED {date}", f"admin:{user}")
    return {"ok": True}


# ------------------------------------------------------------
# Employees
# ------------------------------------------------------------
class EmployeeIn(BaseModel):
    name: str
    employee_id: str = ""
    department: str = ""
    designation: str = ""
    basic_salary: float = 0
    shift: str = "GENERAL"
    whatsapp: str = ""
    active: bool = True


@app.get("/api/employees", dependencies=[Depends(require_admin)])
def employees():
    people = engine.people()
    result = []
    for e in db.list_employees():
        e["photos"] = len(people.get(e["name"], []))
        result.append(e)
    return result


@app.post("/api/employees", dependencies=[Depends(require_admin)])
def save_employee(body: EmployeeIn):
    try:
        return db.upsert_employee(body.model_dump())
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.delete("/api/employees/{name}", dependencies=[Depends(require_admin)])
def remove_employee(name: str, delete_photos: bool = False):
    db.delete_employee(name)
    removed = engine.delete_person(name) if delete_photos else 0
    return {"ok": True, "photos_removed": removed}


@app.get("/api/shifts", dependencies=[Depends(require_admin)])
def shifts():
    return [{"name": k, "start": f"{v['start']:%H:%M}", "end": f"{v['end']:%H:%M}", "hours": v["hours"]}
            for k, v in config.SHIFT_DEFINITIONS.items()]


# ------------------------------------------------------------
# Face enrollment
# ------------------------------------------------------------
@app.post("/api/enroll", dependencies=[Depends(require_admin)])
def enroll(name: str = Form(...), images: List[UploadFile] = File(...)):
    name = name.strip().upper()
    if not name or any(ch in name for ch in '<>:"/\\|?'):
        raise HTTPException(400, "Invalid name")
    saved, rejected = engine.enroll(name, [img.file.read() for img in images])
    if saved:
        db.ensure_employee(name)
    logger.info(f"Enrollment | {name} | saved={len(saved)} rejected={rejected}")
    return {"name": name, "saved": saved, "rejected": rejected}


@app.get("/api/faces", dependencies=[Depends(require_admin)])
def faces():
    return engine.people()


@app.get("/api/faces/image/{filename}", dependencies=[Depends(require_admin)])
def face_image(filename: str):
    path = (config.KNOWN_FACES_DIR / filename).resolve()
    if path.parent != config.KNOWN_FACES_DIR.resolve() or not path.exists():
        raise HTTPException(404)
    return FileResponse(path)


@app.post("/api/faces/reload", dependencies=[Depends(require_admin)])
def reload_faces():
    engine.load_known_faces()
    return {"people": len(engine.people()), "templates": len(engine.names)}


# ------------------------------------------------------------
# Holidays
# ------------------------------------------------------------
class HolidayIn(BaseModel):
    date: str
    description: str = "Public Holiday"


@app.get("/api/holidays", dependencies=[Depends(require_admin)])
def holidays():
    return db.list_holidays()


@app.post("/api/holidays", dependencies=[Depends(require_admin)])
def add_holiday(body: HolidayIn):
    try:
        db.add_holiday(body.date, body.description)
    except ValueError:
        raise HTTPException(400, "Date must be YYYY-MM-DD")
    return {"ok": True}


@app.delete("/api/holidays/{date}", dependencies=[Depends(require_admin)])
def remove_holiday(date: str):
    db.delete_holiday(date)
    return {"ok": True}


# ------------------------------------------------------------
# Reports
# ------------------------------------------------------------
XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


@app.get("/api/reports/daily", dependencies=[Depends(require_admin)])
def daily_report(date: Optional[str] = None, format: str = "xlsx"):
    date = date or datetime.now().strftime("%Y-%m-%d")
    df = payroll.build_daily(date)
    if format == "csv":
        return Response(payroll.to_csv_bytes(df), media_type="text/csv",
                        headers={"Content-Disposition": f'attachment; filename="Attendance_{date}.csv"'})
    return Response(payroll.to_xlsx_bytes({"Daily Payroll": df}), media_type=XLSX_MIME,
                    headers={"Content-Disposition": f'attachment; filename="Daily_Payroll_Summary_{date}.xlsx"'})


@app.get("/api/reports/monthly", dependencies=[Depends(require_admin)])
def monthly_report(month: Optional[str] = None, format: str = "xlsx"):
    month = month or datetime.now().strftime("%Y-%m")
    try:
        summary, details = payroll.build_monthly(month)
    except ValueError:
        raise HTTPException(400, "Month must be YYYY-MM")
    if format == "json":
        return JSONResponse(summary.fillna("").to_dict(orient="records"))
    return Response(payroll.to_xlsx_bytes({"Monthly Summary": summary, "Daily Details": details}),
                    media_type=XLSX_MIME,
                    headers={"Content-Disposition": f'attachment; filename="Monthly_Payroll_Summary_{month}.xlsx"'})


@app.post("/api/reports/email", dependencies=[Depends(require_admin)])
def email_now(date: Optional[str] = None):
    if not email_configured():
        raise HTTPException(400, "Email is not configured in .env")
    ok = send_daily_report_email(date)
    if not ok:
        raise HTTPException(500, "Email failed - check logs")
    return {"ok": True}


# ------------------------------------------------------------
# CCTV live view (rtsp mode)
# ------------------------------------------------------------
@app.get("/api/stream/{action}", dependencies=[Depends(require_admin)])
def stream(action: str):
    cam = cameras.cameras.get(action.upper())
    if not cam:
        raise HTTPException(404, "Camera not running (CAMERA_MODE must be rtsp or both)")
    return StreamingResponse(cam.mjpeg(), media_type="multipart/x-mixed-replace; boundary=frame")
