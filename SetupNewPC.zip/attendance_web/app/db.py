# ============================================================
#  SQLite storage: attendance, employees, holidays, events
#  The attendance table keeps the SAME schema as the old
#  attendance.db, so the existing file can be copied as-is.
# ============================================================
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime

from . import config
from .logger import logger

db_lock = threading.RLock()


@contextmanager
def connect():
    with db_lock:
        conn = sqlite3.connect(config.DB_FILE, timeout=30, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()


def init_db():
    with connect() as conn:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS attendance (
                name TEXT NOT NULL,
                date TEXT NOT NULL,
                checkin TEXT DEFAULT '',
                checkout TEXT DEFAULT '',
                PRIMARY KEY(name, date)
            );
            CREATE TABLE IF NOT EXISTS employees (
                name TEXT PRIMARY KEY,
                employee_id TEXT DEFAULT '',
                department TEXT DEFAULT '',
                designation TEXT DEFAULT '',
                basic_salary REAL DEFAULT 0,
                shift TEXT DEFAULT 'GENERAL',
                whatsapp TEXT DEFAULT '',
                active INTEGER DEFAULT 1
            );
            CREATE TABLE IF NOT EXISTS holidays (
                date TEXT PRIMARY KEY,
                description TEXT DEFAULT 'Public Holiday'
            );
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts TEXT NOT NULL,
                name TEXT NOT NULL,
                action TEXT NOT NULL,
                result TEXT NOT NULL,
                source TEXT DEFAULT '',
                distance REAL
            );
            CREATE INDEX IF NOT EXISTS idx_att_date ON attendance(date);
            CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts);
            """
        )
    logger.info(f"Database ready | {config.DB_FILE}")


# ------------------------------------------------------------
# Employees
# ------------------------------------------------------------
EMPLOYEE_FIELDS = ("employee_id", "department", "designation",
                   "basic_salary", "shift", "whatsapp", "active")


def list_employees(active_only=False):
    sql = "SELECT * FROM employees"
    if active_only:
        sql += " WHERE active=1"
    sql += " ORDER BY name"
    with connect() as conn:
        return [dict(r) for r in conn.execute(sql).fetchall()]


def get_employee(name):
    with connect() as conn:
        row = conn.execute("SELECT * FROM employees WHERE name=?", (name.upper(),)).fetchone()
        return dict(row) if row else None


def upsert_employee(data):
    name = str(data.get("name", "")).strip().upper()
    if not name:
        raise ValueError("Name is required")
    values = {
        "employee_id": str(data.get("employee_id", "") or "").strip(),
        "department": str(data.get("department", "") or "").strip().upper(),
        "designation": str(data.get("designation", "") or "").strip(),
        "basic_salary": float(str(data.get("basic_salary", 0) or 0).replace(",", "")),
        "shift": str(data.get("shift", "GENERAL") or "GENERAL").strip().upper(),
        "whatsapp": normalize_phone(data.get("whatsapp", "")),
        "active": 1 if data.get("active", True) in (True, 1, "1", "true", "True", "Yes", "yes") else 0,
    }
    with connect() as conn:
        conn.execute(
            """
            INSERT INTO employees(name, employee_id, department, designation,
                                  basic_salary, shift, whatsapp, active)
            VALUES (?,?,?,?,?,?,?,?)
            ON CONFLICT(name) DO UPDATE SET
                employee_id=excluded.employee_id, department=excluded.department,
                designation=excluded.designation, basic_salary=excluded.basic_salary,
                shift=excluded.shift, whatsapp=excluded.whatsapp, active=excluded.active
            """,
            (name, values["employee_id"], values["department"], values["designation"],
             values["basic_salary"], values["shift"], values["whatsapp"], values["active"]),
        )
    return get_employee(name)


def ensure_employee(name):
    """Create a blank employee row for a newly enrolled face."""
    name = name.upper()
    with connect() as conn:
        conn.execute("INSERT OR IGNORE INTO employees(name) VALUES (?)", (name,))


def delete_employee(name):
    with connect() as conn:
        conn.execute("DELETE FROM employees WHERE name=?", (name.upper(),))


def normalize_phone(value):
    """Keeps digits only. Rejects Excel scientific notation like 9.23E+11."""
    value = str(value or "").strip()
    if "E+" in value.upper():
        logger.warning(f"Phone number '{value}' is in scientific notation - re-enter it in the web UI")
        return ""
    return "".join(ch for ch in value if ch.isdigit())


# ------------------------------------------------------------
# Holidays
# ------------------------------------------------------------
def list_holidays():
    with connect() as conn:
        return [dict(r) for r in conn.execute("SELECT * FROM holidays ORDER BY date").fetchall()]


def holiday_map():
    return {h["date"]: h["description"] for h in list_holidays()}


def add_holiday(date_str, description):
    datetime.strptime(date_str, "%Y-%m-%d")
    with connect() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO holidays(date, description) VALUES (?,?)",
            (date_str, description or "Public Holiday"),
        )


def delete_holiday(date_str):
    with connect() as conn:
        conn.execute("DELETE FROM holidays WHERE date=?", (date_str,))


# ------------------------------------------------------------
# Attendance
# ------------------------------------------------------------
def get_attendance(name, date_str):
    with connect() as conn:
        row = conn.execute(
            "SELECT name, date, checkin, checkout FROM attendance WHERE name=? AND date=?",
            (name.upper(), date_str),
        ).fetchone()
        return dict(row) if row else None


def attendance_for_date(date_str):
    with connect() as conn:
        rows = conn.execute(
            "SELECT name, date, checkin, checkout FROM attendance WHERE date=? ORDER BY name",
            (date_str,),
        ).fetchall()
        return [dict(r) for r in rows]


def attendance_between(start_date, end_date_exclusive):
    with connect() as conn:
        rows = conn.execute(
            "SELECT name, date, checkin, checkout FROM attendance "
            "WHERE date>=? AND date<? ORDER BY name, date",
            (start_date, end_date_exclusive),
        ).fetchall()
        return [dict(r) for r in rows]


def set_attendance(name, date_str, checkin, checkout):
    """Manual correction from the admin panel."""
    with connect() as conn:
        conn.execute(
            """
            INSERT INTO attendance(name, date, checkin, checkout) VALUES (?,?,?,?)
            ON CONFLICT(name, date) DO UPDATE SET checkin=excluded.checkin, checkout=excluded.checkout
            """,
            (name.upper(), date_str, checkin or "", checkout or ""),
        )


def delete_attendance(name, date_str):
    with connect() as conn:
        conn.execute("DELETE FROM attendance WHERE name=? AND date=?", (name.upper(), date_str))


# ------------------------------------------------------------
# Events (audit trail shown on dashboard)
# ------------------------------------------------------------
def log_event(name, action, result, source="", distance=None):
    with connect() as conn:
        conn.execute(
            "INSERT INTO events(ts, name, action, result, source, distance) VALUES (?,?,?,?,?,?)",
            (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), name, action, result, source, distance),
        )


def recent_events(limit=50):
    with connect() as conn:
        rows = conn.execute("SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]
