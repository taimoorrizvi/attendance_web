# ============================================================
#  PAYROLL / OT CALCULATION (ported from app_payroll.py)
#  Reports are built in memory - no more "Permission denied"
#  when the Excel file is open.
# ============================================================
import io
from datetime import date, datetime, timedelta

import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill

from . import config, db

DAILY_COLUMNS = [
    "Employee ID", "Name", "Department", "Designation", "Basic Salary", "Shift", "Date", "Day",
    "Check In", "Check Out", "Worked Hrs", "Regular Hrs", "Late Min", "Late Adjustment Min",
    "Early Out Min", "OT Hrs", "OT Rule", "OT Rate", "OT Calculation", "OT Amount",
    "Sunday/Public Holiday", "Remarks",
]

MONTHLY_COLUMNS = [
    "Employee ID", "Name", "Department", "Designation", "Basic Salary", "Working Days",
    "Present Days", "Absent Days", "Worked Hrs", "OT Hrs", "OT Amount", "Late Min",
    "Late Adjustment Min",
]


def normalize_shift(value, department=""):
    value = str(value or "").strip().upper()
    department = str(department or "").strip().upper()
    if department in ("LOGISTICS", "PRODUCTION") and value in ("DAY", "NIGHT", "EVENING"):
        candidate = f"{department} {value}"
        if candidate in config.SHIFT_DEFINITIONS:
            return candidate
    if value in config.SHIFT_DEFINITIONS:
        return value
    return "GENERAL"


def _employee_or_default(name, employees):
    return employees.get(name.upper(), {
        "employee_id": "", "name": name.upper(), "department": "", "designation": "",
        "basic_salary": 0.0, "shift": "GENERAL", "whatsapp": "", "active": 1,
    })


def _ot_hours_basic(date_str, checkin, checkout, emp, holidays):
    """Lightweight previous-day OT used for the late-sitting grace rule."""
    try:
        shift = config.SHIFT_DEFINITIONS[normalize_shift(emp.get("shift"), emp.get("department"))]
        cin = datetime.strptime(f"{date_str} {checkin}", "%Y-%m-%d %H:%M:%S")
        cout = datetime.strptime(f"{date_str} {checkout}", "%Y-%m-%d %H:%M:%S")
        if cout < cin:
            cout += timedelta(days=1)
        worked = max(0.0, (cout - cin).total_seconds() / 3600.0)
        if cin.strftime("%A") == "Sunday" or date_str in holidays:
            return worked
        return max(0.0, worked - float(shift["hours"]))
    except Exception:
        return 0.0


def calculate_row(name, date_str, checkin, checkout, employees, holidays, prev_rows):
    emp = _employee_or_default(name, employees)
    shift_name = normalize_shift(emp.get("shift"), emp.get("department"))
    info = config.SHIFT_DEFINITIONS[shift_name]
    scheduled_hours = float(info["hours"])

    day_name = datetime.strptime(date_str, "%Y-%m-%d").strftime("%A")
    is_sunday = day_name == "Sunday"
    is_holiday = date_str in holidays
    holiday_reason = "Sunday" if is_sunday else holidays.get(date_str, "")

    worked = regular = ot_hours = ot_rate = ot_amount = 0.0
    late_min = early_min = late_adj = 0
    ot_rule = ot_calc = remarks = ""

    if checkin and checkout:
        cin = datetime.strptime(f"{date_str} {checkin}", "%Y-%m-%d %H:%M:%S")
        cout = datetime.strptime(f"{date_str} {checkout}", "%Y-%m-%d %H:%M:%S")
        if cout < cin:                       # overnight shift
            cout += timedelta(days=1)
        worked = max(0.0, (cout - cin).total_seconds() / 3600.0)

        shift_start = datetime.combine(cin.date(), info["start"])
        late_min = max(0, int(round((cin - shift_start).total_seconds() / 60.0)))
        regular = min(worked, scheduled_hours)

        salary = float(emp.get("basic_salary") or 0)
        dept = str(emp.get("department") or "").upper()
        designation = str(emp.get("designation") or "").upper()

        if is_sunday or is_holiday:
            ot_hours = worked
            base_hourly = salary / config.MONTHLY_WORKING_DAYS / scheduled_hours if salary > 0 else 0.0
            ot_rate = base_hourly * config.HOLIDAY_OT_MULTIPLIER
            ot_rule = f"{holiday_reason} - actual worked time x {config.HOLIDAY_OT_MULTIPLIER}"
            ot_calc = f"{worked:.2f} hrs x PKR {base_hourly:.2f}/hr x {config.HOLIDAY_OT_MULTIPLIER}"
            ot_amount = ot_hours * ot_rate
        else:
            ot_hours = max(0.0, worked - scheduled_hours)
            if dept == "LOGISTICS" and ot_hours >= 5:
                if "SUPERV" in designation:
                    ot_rule, ot_amount, ot_rate = "Logistics - 5+ hours - Supervisory", 1250.0, 1250.0
                    ot_calc = "Fixed PKR 1,250"
                else:
                    ot_rule, ot_amount, ot_rate = "Logistics - 5+ hours - Low Designation", 1000.0, 1000.0
                    ot_calc = "Fixed PKR 1,000"
            else:
                if dept == "PRODUCTION":
                    ot_rate = 40.0 if salary < 50000 else 50.0
                    ot_rule = ("Production - salary below PKR 50,000" if salary < 50000
                               else "Production - salary PKR 50,000 or above")
                elif dept in ("QUALITY ASSURANCE", "QA", "ADMIN", "STORE", "STORES"):
                    ot_rate, ot_rule = 40.0, f"{dept} - normal working day"
                elif dept == "LOGISTICS":
                    ot_rate, ot_rule = 40.0, "Logistics - up to 4 hours"
                else:
                    ot_rate, ot_rule = 40.0, "Default OT rate - PKR 40/hour"
                ot_amount = ot_hours * ot_rate
                ot_calc = f"{ot_hours:.2f} hrs x PKR {ot_rate:.2f}"

            end_date = cin.date() + (timedelta(days=1) if info["end"] < info["start"] else timedelta(0))
            shift_end = datetime.combine(end_date, info["end"])
            if cout < shift_end:
                early_min = max(0, int(round((shift_end - cout).total_seconds() / 60.0)))

        # Late-sitting grace: 2h+ OT yesterday forgives up to 120 late minutes today
        prev = prev_rows.get(name.upper())
        if prev and prev.get("checkin") and prev.get("checkout") and late_min > 0:
            if _ot_hours_basic(prev["date"], prev["checkin"], prev["checkout"], emp, holidays) >= 2.0:
                late_adj = min(late_min, config.NEXT_DAY_LATE_GRACE_MINUTES)
                late_min -= late_adj
                remarks = f"Late sitting grace applied: {late_adj} min"
    elif checkin and not checkout:
        remarks = "Checked in - no check-out yet"
    elif checkout and not checkin:
        remarks = "Check-out only - check-in missing"

    return {
        "Employee ID": emp.get("employee_id", ""), "Name": name.upper(),
        "Department": emp.get("department", ""), "Designation": emp.get("designation", ""),
        "Basic Salary": round(float(emp.get("basic_salary") or 0), 2), "Shift": shift_name,
        "Date": date_str, "Day": day_name, "Check In": checkin or "", "Check Out": checkout or "",
        "Worked Hrs": round(worked, 2), "Regular Hrs": round(regular, 2),
        "Late Min": late_min, "Late Adjustment Min": late_adj, "Early Out Min": early_min,
        "OT Hrs": round(ot_hours, 2), "OT Rule": ot_rule, "OT Rate": round(ot_rate, 2),
        "OT Calculation": ot_calc, "OT Amount": round(ot_amount, 2),
        "Sunday/Public Holiday": holiday_reason, "Remarks": remarks,
    }


def _prev_rows_for(date_str):
    prev_date = (datetime.strptime(date_str, "%Y-%m-%d").date() - timedelta(days=1)).strftime("%Y-%m-%d")
    return {r["name"].upper(): r for r in db.attendance_for_date(prev_date)}


def build_daily(date_str):
    employees = {e["name"]: e for e in db.list_employees()}
    holidays = db.holiday_map()
    attendance = {r["name"].upper(): r for r in db.attendance_for_date(date_str)}
    prev_rows = _prev_rows_for(date_str)

    names = set(attendance) | {n for n, e in employees.items() if e.get("active")}
    rows = []
    for name in sorted(names):
        rec = attendance.get(name, {})
        row = calculate_row(name, date_str, rec.get("checkin", ""), rec.get("checkout", ""),
                            employees, holidays, prev_rows)
        if not rec:
            off = row["Sunday/Public Holiday"]
            row["Remarks"] = f"OFF - {off}" if off else "ABSENT / No attendance detected"
        rows.append(row)
    return pd.DataFrame(rows, columns=DAILY_COLUMNS)


def build_monthly(month_str):
    first = datetime.strptime(f"{month_str}-01", "%Y-%m-%d").date()
    next_month = (first.replace(day=28) + timedelta(days=4)).replace(day=1)
    employees = {e["name"]: e for e in db.list_employees()}
    holidays = db.holiday_map()

    records = db.attendance_between(first.strftime("%Y-%m-%d"), next_month.strftime("%Y-%m-%d"))
    by_date = {}
    for r in records:
        by_date.setdefault(r["date"], {})[r["name"].upper()] = r

    # Working days = Mon-Sat, excluding public holidays, up to today for the current month
    last_day = min(next_month - timedelta(days=1), date.today())
    working_days = 0
    d = first
    while d <= last_day:
        if d.strftime("%A") != "Sunday" and d.strftime("%Y-%m-%d") not in holidays:
            working_days += 1
        d += timedelta(days=1)

    daily_rows = []
    for r in records:
        prev_date = (datetime.strptime(r["date"], "%Y-%m-%d").date() - timedelta(days=1)).strftime("%Y-%m-%d")
        prev_rows = by_date.get(prev_date) or _prev_rows_for(r["date"])
        daily_rows.append(calculate_row(r["name"], r["date"], r["checkin"], r["checkout"],
                                        employees, holidays, prev_rows))

    summary = {}
    for name, emp in employees.items():
        summary[name] = {
            "Employee ID": emp["employee_id"], "Name": name, "Department": emp["department"],
            "Designation": emp["designation"], "Basic Salary": emp["basic_salary"],
            "Working Days": working_days, "Present Days": 0, "Absent Days": 0,
            "Worked Hrs": 0.0, "OT Hrs": 0.0, "OT Amount": 0.0, "Late Min": 0,
            "Late Adjustment Min": 0,
        }
    for row in daily_rows:
        s = summary.setdefault(row["Name"], {
            "Employee ID": row["Employee ID"], "Name": row["Name"], "Department": row["Department"],
            "Designation": row["Designation"], "Basic Salary": row["Basic Salary"],
            "Working Days": working_days, "Present Days": 0, "Absent Days": 0, "Worked Hrs": 0.0,
            "OT Hrs": 0.0, "OT Amount": 0.0, "Late Min": 0, "Late Adjustment Min": 0,
        })
        if row["Check In"] or row["Check Out"]:
            s["Present Days"] += 1
        s["Worked Hrs"] += row["Worked Hrs"]
        s["OT Hrs"] += row["OT Hrs"]
        s["OT Amount"] += row["OT Amount"]
        s["Late Min"] += row["Late Min"]
        s["Late Adjustment Min"] += row["Late Adjustment Min"]

    for s in summary.values():
        s["Absent Days"] = max(0, working_days - s["Present Days"])
        for k in ("Worked Hrs", "OT Hrs", "OT Amount"):
            s[k] = round(s[k], 2)

    monthly = pd.DataFrame(sorted(summary.values(), key=lambda x: x["Name"]), columns=MONTHLY_COLUMNS)
    details = pd.DataFrame(daily_rows, columns=DAILY_COLUMNS)
    return monthly, details


# ------------------------------------------------------------
# Export helpers
# ------------------------------------------------------------
def _style_sheet(ws):
    red = Font(color="FF0000", bold=True)
    header_fill = PatternFill("solid", fgColor="1F4E78")
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = header_fill
    headers = {cell.value: cell.column for cell in ws[1]}
    for row in range(2, ws.max_row + 1):
        for col_name in ("Late Min", "Early Out Min", "Absent Days"):
            if col_name in headers:
                c = ws.cell(row=row, column=headers[col_name])
                if isinstance(c.value, (int, float)) and c.value > 0:
                    c.font = red
        if "Remarks" in headers:
            c = ws.cell(row=row, column=headers["Remarks"])
            if c.value and "ABSENT" in str(c.value):
                c.font = red
        for col_name in ("OT Amount", "Basic Salary"):
            if col_name in headers:
                ws.cell(row=row, column=headers[col_name]).number_format = "#,##0.00"
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    for column_cells in ws.columns:
        max_len = max(len(str(c.value or "")) for c in column_cells[:200])
        ws.column_dimensions[column_cells[0].column_letter].width = min(max(max_len + 2, 10), 45)


def to_xlsx_bytes(sheets):
    """sheets: dict of sheet_name -> DataFrame"""
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        for sheet_name, df in sheets.items():
            df.to_excel(writer, index=False, sheet_name=sheet_name[:31])
    buf.seek(0)
    wb = load_workbook(buf)
    for ws in wb.worksheets:
        _style_sheet(ws)
    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()


def to_csv_bytes(df):
    return df.to_csv(index=False).encode("utf-8-sig")
