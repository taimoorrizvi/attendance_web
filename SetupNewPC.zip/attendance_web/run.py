# Start the web server:  python run.py
import uvicorn

from app import config

if __name__ == "__main__":
    ssl = {}
    if config.SSL_CERTFILE and config.SSL_KEYFILE:
        ssl = {"ssl_certfile": config.SSL_CERTFILE, "ssl_keyfile": config.SSL_KEYFILE}
    scheme = "https" if ssl else "http"
    print(f"\n  Admin : {scheme}://localhost:{config.PORT}/")
    print(f"  Kiosk : {scheme}://localhost:{config.PORT}/kiosk\n")
    # workers=1 on purpose: the face model and camera threads live in this process
    uvicorn.run("app.main:app", host=config.HOST, port=config.PORT, workers=1, **ssl)
