"""
Creates a self-signed HTTPS certificate so other PCs/tablets on the LAN can use
the webcam in /kiosk (browsers block cameras on plain http:// except localhost).

Usage:
    python tools\\make_cert.py 192.168.1.50      (the server's LAN IP)
Then set in .env:
    SSL_CERTFILE=data/cert.pem
    SSL_KEYFILE=data/key.pem
"""
import ipaddress
import socket
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

out = Path(__file__).resolve().parent.parent / "data"
out.mkdir(exist_ok=True)

ips = {"127.0.0.1"}
if len(sys.argv) > 1:
    ips.update(sys.argv[1:])
else:
    try:
        ips.add(socket.gethostbyname(socket.gethostname()))
    except Exception:
        pass

key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "attendance.local")])
san = [x509.DNSName("localhost"), x509.DNSName(socket.gethostname())]
san += [x509.IPAddress(ipaddress.ip_address(ip)) for ip in ips]
now = datetime.now(timezone.utc)
cert = (
    x509.CertificateBuilder()
    .subject_name(name).issuer_name(name).public_key(key.public_key())
    .serial_number(x509.random_serial_number())
    .not_valid_before(now - timedelta(days=1)).not_valid_after(now + timedelta(days=3650))
    .add_extension(x509.SubjectAlternativeName(san), critical=False)
    .sign(key, hashes.SHA256())
)
(out / "key.pem").write_bytes(key.private_bytes(
    serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL, serialization.NoEncryption()))
(out / "cert.pem").write_bytes(cert.public_bytes(serialization.Encoding.PEM))
print(f"Created data/cert.pem and data/key.pem for: {', '.join(sorted(ips))}")
print("Add to .env:\n  SSL_CERTFILE=data/cert.pem\n  SSL_KEYFILE=data/key.pem")
