"""
Import data from the old desktop version.

Usage (from the project folder):
    python tools\\migrate_old.py "D:\\AttendenceSystem"

Copies: attendance.db rows, known_faces photos, Employee_Master.csv, Public_Holidays.csv
Safe to run more than once (existing rows are kept / updated).
"""
import shutil
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd  # noqa: E402

from app import config, db  # noqa: E402


def main(old_dir):
    old = Path(old_dir)
    if not old.is_dir():
        sys.exit(f"Folder not found: {old}")
    db.init_db()

    # 1) Face photos
    src_faces = old / "known_faces"
    copied = 0
    if src_faces.is_dir():
        for f in src_faces.iterdir():
            if f.suffix.lower() in (".jpg", ".jpeg", ".png"):
                target = config.KNOWN_FACES_DIR / f.name
                if not target.exists():
                    shutil.copy2(f, target)
                    copied += 1
    print(f"[faces] copied {copied} photo(s) -> {config.KNOWN_FACES_DIR}")

    # 2) Attendance rows
    old_db = old / "attendance.db"
    if old_db.exists():
        src = sqlite3.connect(old_db)
        rows = src.execute("SELECT name, date, checkin, checkout FROM attendance").fetchall()
        src.close()
        with db.connect() as conn:
            conn.executemany(
                "INSERT OR IGNORE INTO attendance(name,date,checkin,checkout) VALUES (?,?,?,?)",
                [(r[0].upper(), r[1], r[2] or "", r[3] or "") for r in rows],
            )
        print(f"[attendance] imported {len(rows)} row(s)")

    # 3) Employee master
    emp_csv = old / "Employee_Master.csv"
    if emp_csv.exists():
        df = pd.read_csv(emp_csv, dtype=str).fillna("")
        for _, r in df.iterrows():
            if not str(r.get("Name", "")).strip():
                continue
            phone_raw = str(r.get("WhatsApp Number", ""))
            emp = db.upsert_employee({
                "name": r.get("Name"), "employee_id": r.get("Employee ID"),
                "department": r.get("Department"), "designation": r.get("Designation"),
                "basic_salary": r.get("Basic Salary") or 0, "shift": r.get("Shift") or "GENERAL",
                "whatsapp": phone_raw,
                "active": str(r.get("Active", "Yes")).strip().upper() not in ("NO", "0", "FALSE", "INACTIVE"),
            })
            note = ""
            if phone_raw and not emp["whatsapp"]:
                note = f"  <-- WhatsApp '{phone_raw}' was corrupted by Excel, re-enter it in the web UI"
            print(f"[employee] {emp['name']}{note}")

    # 4) Holidays
    hol_csv = old / "Public_Holidays.csv"
    if hol_csv.exists():
        df = pd.read_csv(hol_csv, dtype=str).fillna("")
        n = 0
        for _, r in df.iterrows():
            if str(r.get("Date", "")).strip():
                db.add_holiday(pd.to_datetime(r["Date"]).strftime("%Y-%m-%d"), r.get("Description") or "Public Holiday")
                n += 1
        print(f"[holidays] imported {n}")

    print("\nDone. Start the server with: python run.py")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit('Usage: python tools\\migrate_old.py "D:\\AttendenceSystem"')
    main(sys.argv[1])
