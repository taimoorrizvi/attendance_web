# Nizam Energy – AI Face Attendance (Web Version)

The desktop scripts (`app_payroll.py` + `capture_worker.py`) converted into a **FastAPI web application**.
Same ArcFace (InsightFace `buffalo_l`) recognition, same payroll/OT rules – now with a browser UI.

| URL | Who | What |
|---|---|---|
| `http://localhost:8000/` | Admin (login) | Dashboard, attendance, employees, face enrollment, holidays, reports, CCTV view |
| `http://localhost:8000/kiosk` | Gate PC / tablet | Webcam check-in / check-out screen |
| `http://localhost:8000/docs` | Developer | Swagger API docs |

## Folder layout

```
attendance_web\
  app\            Python backend (FastAPI)
  static\         Web UI (admin + kiosk)
  tools\          migrate_old.py, make_cert.py
  data\           created automatically: attendance.db, known_faces\, logs\
  .env            your settings (copy of .env.example)
  setup.bat       one-time install
  start.bat       start the server
```

## 1. Install (Windows, one time)

Requirements: Python 3.10–3.12 (same one you used before), NVIDIA driver for the GTX 1060,
and Microsoft C++ Build Tools (already present if insightface installed before).

```bat
cd D:\attendance_web
setup.bat
```

`setup.bat` creates `venv`, installs packages, **removes the CPU-only `onnxruntime`** and installs
`onnxruntime-gpu` with CUDA/cuDNN DLLs. Your old log shows
`providers: ['AzureExecutionProvider', 'CPUExecutionProvider']` – that is why it never used the GPU.

Verify GPU:

```bat
venv\Scripts\python check_gpu.py
```

## 2. Configure

Edit `.env` (created from `.env.example`). Minimum:

```
ADMIN_PASSWORD=YourStrongPassword
SENDER_PASSWORD=your-16-char-gmail-app-password
TEST_MODE=true        (24h windows for demo, set false for production)
```

## 3. Import your old data

```bat
venv\Scripts\python tools\migrate_old.py "D:\AttendenceSystem"
```

Copies `known_faces`, `attendance.db` rows, `Employee_Master.csv`, `Public_Holidays.csv`.

> Your `Employee_Master.csv` has WhatsApp = `9.23E+11` – Excel converted the number to scientific
> notation and the real digits are lost. Re-enter it in **Employees** tab. Employees now live in the
> database, so this cannot happen again.

## 4. Run

```bat
start.bat
```

Open `http://localhost:8000/` → login → **Face Enrollment** tab to add people from the browser webcam,
then open `http://localhost:8000/kiosk` on the gate PC.

Keep your WhatsApp bridge (port 3000) running as before – e.g. from your existing `start_all.bat`.

## 5. Use from other PCs / tablets on the LAN

Browsers only allow the webcam on `https://` or `http://localhost`. For other devices:

```bat
venv\Scripts\python tools\make_cert.py 192.168.1.50
```

(use the server's LAN IP), then add to `.env`:

```
SSL_CERTFILE=data/cert.pem
SSL_KEYFILE=data/key.pem
```

Restart, open `https://192.168.1.50:8000/kiosk`, accept the certificate warning once.
Allow port 8000 in Windows Firewall:

```bat
netsh advfirewall firewall add rule name="Attendance 8000" dir=in action=allow protocol=TCP localport=8000
```

Optional: set `KIOSK_KEY=somesecret` so only devices that know the key can mark attendance.

## 6. CCTV mode

```
CAMERA_MODE=rtsp          (or "both" to keep the browser kiosk too)
IN_CAMERA_URL=rtsp://user:pass@192.168.1.100:554/stream2
OUT_CAMERA_URL=rtsp://user:pass@192.168.1.101:554/stream2
```

Recognition runs on the server; live annotated video is in the **CCTV** tab.

## 7. Run at Windows startup (optional)

Task Scheduler → Create Task → Trigger "At startup" → Action: `D:\attendance_web\start.bat`,
"Run whether user is logged on or not".

## What changed vs. the old scripts

| Old behaviour | Web version |
|---|---|
| OpenCV window, click IN/OUT | Browser kiosk, any PC/tablet, big IN/OUT buttons, beep + on-screen banner |
| Check-out re-saved every ~2 s while standing in front of camera (WhatsApp spam in log) | Re-saved only after `CHECKOUT_UPDATE_COOLDOWN` (default 5 min) |
| Excel file locked → `Permission denied` / `Access is denied` in log | Reports generated on demand in memory – no files locked |
| Employees/holidays in CSV (Excel corrupts phone numbers) | Stored in SQLite, edited in the web UI |
| Gmail address + phone numbers hard-coded in .py | Everything in `.env` / database |
| Enrollment via console script | Enrollment in browser (webcam or file upload); photos without a face are rejected |
| Face templates re-computed every start | Embedding cache – fast restarts |
| Monthly absent days counted Sundays and future days | Working days = Mon–Sat minus public holidays, up to today |
| Sunday with no attendance = "ABSENT" | Shows "OFF - Sunday" |
| — | Manual attendance correction + full audit log of events |

Payroll/OT rules (shifts, PKR 40/50 rates, logistics fixed 1,000/1,250, holiday 1.75x, late-sitting grace)
are unchanged and live in `app/payroll.py` and `app/config.py`.

## Troubleshooting

- **Camera blocked on kiosk** → use `https://` (step 5) or open on the server itself via `localhost`.
- **AI engine shows CPU** → `pip uninstall -y onnxruntime` then `pip install "onnxruntime-gpu[cuda,cudnn]"`.
- **Wrong person matched** → lower `MATCH_THRESHOLD` (e.g. 0.38). **Not recognized** → raise it slightly or enroll more photos.
- Logs: `data\logs\attendance_system.log`.
