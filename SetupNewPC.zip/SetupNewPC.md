# Nizam Energy AI Face Attendance — Windows Server (GPU) Deployment Guide

This guide deploys the web version (`attendance_web.zip`, native Python, no Docker) on a Windows Server
with an NVIDIA GPU, runs it as a Windows service that starts automatically, and makes the kiosk
usable from other PCs and tablets over HTTPS.

Follow the steps in order. Every command is meant for PowerShell or Command Prompt opened
as Administrator, unless stated otherwise.

---

## Contents

1. Server requirements
2. Prepare Windows Server
3. Install the NVIDIA driver
4. Install Visual C++ Build Tools and Redistributable
5. Install Python 3.11
6. Copy the application
7. Create the virtual environment and install packages
8. Enable the GPU (onnxruntime-gpu)
9. Download the face model
10. Configure `.env`
11. Import data from the old system
12. First manual run and test
13. HTTPS for kiosks and tablets
14. Windows Firewall
15. Run as a Windows service (NSSM)
16. WhatsApp bridge as a service
17. Trust the certificate on kiosk devices
18. Daily backup
19. Updating the application
20. Verification checklist
21. Troubleshooting
22. Quick command reference

---

## 1. Server requirements

| Item | Requirement |
|---|---|
| OS | Windows Server 2019 or 2022 (Desktop Experience), 64-bit |
| CPU / RAM | 4+ cores, 8 GB RAM minimum (16 GB recommended) |
| GPU | NVIDIA GPU with driver 528 or newer (CUDA 12 support). GTX 1060 works (compute 6.1) |
| Disk | 10 GB free (app, Python, CUDA libraries, model, data) |
| Network | Static LAN IP (example in this guide: `192.168.1.50`) |
| Internet | Needed during install (pip packages + face model). Not needed at runtime except email/WhatsApp |
| Account | Local Administrator |

Folder used in this guide: `D:\attendance_web`. If you use another drive, replace it everywhere.

---

## 2. Prepare Windows Server

### 2.1 Set the time zone (check-in times and the 10 PM email depend on it)

```powershell
Set-TimeZone -Id "Pakistan Standard Time"
Get-TimeZone
```

### 2.2 Set a static IP

Server Manager → Local Server → Ethernet → IPv4 → set a fixed IP, gateway and DNS.
Confirm:

```powershell
ipconfig
```

### 2.3 Disable IE Enhanced Security (only to download installers easily)

Server Manager → Local Server → IE Enhanced Security Configuration → Off (Administrators).

### 2.4 Proxy (only if your network needs one)

```powershell
setx HTTP_PROXY  "http://proxy.company.local:8080" /M
setx HTTPS_PROXY "http://proxy.company.local:8080" /M
setx NO_PROXY    "localhost,127.0.0.1,192.168.1.50" /M
```

Close and reopen the terminal after `setx`.

### 2.5 Apply Windows Updates and reboot

---

## 3. Install the NVIDIA driver

1. Download the driver for your GPU from https://www.nvidia.com/Download/index.aspx
   - Datacenter/Quadro/RTX A-series cards: choose the Windows Server driver.
   - GeForce cards (e.g. GTX 1060): choose "Windows 10/11 64-bit". On Windows Server the installer
     may refuse; if so, extract it (it unpacks to `C:\NVIDIA\DisplayDriver\...`), then in
     Device Manager → Display adapters → Update driver → Browse → point to the extracted
     `Display.Driver` folder.
2. Reboot.
3. Verify:

```powershell
nvidia-smi
```

You must see the GPU name and a "CUDA Version: 12.x" (or higher) in the top-right corner.
You do NOT need to install the CUDA Toolkit or cuDNN separately — they come as pip packages in step 8.

---

## 4. Install Visual C++ Build Tools and Redistributable

InsightFace is compiled during install, so the C++ compiler is required.

1. Download Build Tools for Visual Studio 2022: https://visualstudio.microsoft.com/visual-cpp-build-tools/
2. Run it and tick "Desktop development with C++" (keep the default MSVC v143 + Windows SDK items).
3. Install the Visual C++ Redistributable x64: https://aka.ms/vs/17/release/vc_redist.x64.exe
4. Reboot.

---

## 5. Install Python 3.11

Use Python 3.11 (best compatibility with insightface and onnxruntime-gpu).

1. Download Python 3.11.9 64-bit from https://www.python.org/downloads/release/python-3119/
   ("Windows installer (64-bit)").
2. Run the installer:
   - Tick "Add python.exe to PATH".
   - Click "Customize installation" → keep all → Next → tick "Install for all users".
   - Install location: `C:\Python311`.
   - After install, click "Disable path length limit".
3. Open a NEW terminal and verify:

```powershell
python --version
pip --version
```

Expected: `Python 3.11.9`.

---

## 6. Copy the application

1. Copy `attendance_web.zip` to the server and extract it to `D:\`, so you have:

```
D:\attendance_web\
    app\
    static\
    tools\
    run.py
    requirements.txt
    .env.example
    setup.bat
    start.bat
    check_gpu.py
    README.md
```

2. Right-click the zip → Properties → tick "Unblock" before extracting (otherwise Windows may block the .bat files).

---

## 7. Create the virtual environment and install packages

```powershell
cd D:\attendance_web
python -m venv venv
.\venv\Scripts\activate
python -m pip install --upgrade pip setuptools wheel
pip install "numpy<2.0" cython
pip install fastapi "uvicorn[standard]" python-multipart python-dotenv pandas openpyxl opencv-python requests cryptography
pip install insightface==0.7.3
```

If PowerShell blocks `activate` with an execution-policy error:

```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

If `insightface` fails with "Microsoft Visual C++ 14.0 or greater is required", step 4 was not
completed — install Build Tools, open a new terminal, and repeat.

---

## 8. Enable the GPU (onnxruntime-gpu)

Only ONE onnxruntime package may be installed. The CPU package hides the GPU.

```powershell
cd D:\attendance_web
.\venv\Scripts\activate
pip uninstall -y onnxruntime onnxruntime-gpu
pip install "onnxruntime-gpu[cuda,cudnn]"
python check_gpu.py
```

Expected output:

```
providers   ['TensorrtExecutionProvider', 'CUDAExecutionProvider', 'CPUExecutionProvider']
GPU OK
```

The `[cuda,cudnn]` extra installs the CUDA 12 and cuDNN DLLs inside
`venv\Lib\site-packages\nvidia\...`; the app adds those folders to the DLL search path automatically.

If it prints `GPU NOT AVAILABLE`, see Troubleshooting → "AI engine shows CPU".

---

## 9. Download the face model

The `buffalo_l` model (~280 MB) is downloaded on first start into `%USERPROFILE%\.insightface`.
Because the service (step 15) runs under a different profile, keep the model inside the app folder.

```powershell
cd D:\attendance_web
mkdir home
$env:USERPROFILE = "D:\attendance_web\home"
.\venv\Scripts\python -c "from insightface.app import FaceAnalysis; FaceAnalysis(name='buffalo_l', providers=['CPUExecutionProvider'])"
dir D:\attendance_web\home\.insightface\models\buffalo_l
```

You should see five `.onnx` files (`det_10g.onnx`, `w600k_r50.onnx`, etc.).

No internet on the server? Download `buffalo_l.zip` on another PC from
https://github.com/deepinsight/insightface/releases/download/v0.7/buffalo_l.zip and extract it to
`D:\attendance_web\home\.insightface\models\buffalo_l\`.

---

## 10. Configure `.env`

```powershell
cd D:\attendance_web
copy .env.example .env
notepad .env
```

Production values to set:

```
APP_NAME=Nizam Energy AI Attendance
HOST=0.0.0.0
PORT=8000

ADMIN_USER=admin
ADMIN_PASSWORD=Use-A-Strong-Password-Here

KIOSK_KEY=

SSL_CERTFILE=
SSL_KEYFILE=

CAMERA_MODE=browser
USE_GPU=true
MATCH_THRESHOLD=0.42

TEST_MODE=false
CHECKIN_START=08:00
CHECKIN_END=18:00
CHECKOUT_START=08:00
CHECKOUT_END=22:00
CHECKOUT_UPDATE_COOLDOWN=300

WHATSAPP_ENABLED=true
WHATSAPP_BRIDGE_URL=http://localhost:3000/send-message

SENDER_EMAIL=syedboozarali.nizamenergy@gmail.com
SENDER_PASSWORD=your-16-character-gmail-app-password
RECEIVER_EMAIL=boozar110@gmail.com
DAILY_REPORT_HOUR=22
```

Notes:
- `SENDER_PASSWORD` is a Gmail App Password (Google Account → Security → 2-Step Verification → App passwords), not the normal password.
- For a demo, set `TEST_MODE=true` (24-hour check-in/check-out windows).
- For CCTV cameras, set `CAMERA_MODE=rtsp` (or `both`) and fill `IN_CAMERA_URL` / `OUT_CAMERA_URL`.
- SSL lines are filled in step 13.

---

## 11. Import data from the old system

Copy the old folder (with `attendance.db`, `known_faces`, `Employee_Master.csv`, `Public_Holidays.csv`)
to the server, e.g. `D:\AttendenceSystem`, then:

```powershell
cd D:\attendance_web
.\venv\Scripts\python tools\migrate_old.py "D:\AttendenceSystem"
```

Output shows copied photos, imported rows and employees. If you see
"WhatsApp '9.23E+11' was corrupted by Excel", re-enter that number later in the Employees tab.

---

## 12. First manual run and test

```powershell
cd D:\attendance_web
$env:USERPROFILE = "D:\attendance_web\home"
.\venv\Scripts\python run.py
```

Wait for `Application startup complete`. In the log you should see:

```
ArcFace engine ready on GPU (CUDA)
Face templates loaded: N images | M people
```

On the server itself, open:
- Admin: http://localhost:8000/ (login with `ADMIN_USER` / `ADMIN_PASSWORD`)
- Kiosk: http://localhost:8000/kiosk

Check the Dashboard card "AI engine" = `GPU (CUDA)`. Then stop with `Ctrl+C`.

---

## 13. HTTPS for kiosks and tablets

Browsers allow webcam access only on `https://` or `http://localhost`. Every kiosk PC/tablet that is
not the server itself needs HTTPS.

### Option A — Self-signed certificate (quick)

```powershell
cd D:\attendance_web
.\venv\Scripts\python tools\make_cert.py 192.168.1.50
```

Then in `.env`:

```
SSL_CERTFILE=data/cert.pem
SSL_KEYFILE=data/key.pem
```

Clients open `https://192.168.1.50:8000/kiosk`. Install the certificate on each client (step 17)
so the browser does not show warnings and keeps camera permission.

### Option B — Company certificate (recommended for production)

If you have a company/internal CA certificate for a DNS name such as `attendance.baf.com`:
1. Export it as PEM: `cert.pem` (certificate + chain) and `key.pem` (unencrypted private key).
2. Copy both to `D:\attendance_web\data\`.
3. Set the same two `.env` lines as Option A.
4. Create a DNS A record `attendance.baf.com` → `192.168.1.50`.

Clients open `https://attendance.baf.com:8000/kiosk` — no warnings, nothing to install.

---

## 14. Windows Firewall

```powershell
New-NetFirewallRule -DisplayName "Nizam Attendance 8000" -Direction Inbound -Protocol TCP -LocalPort 8000 -Action Allow -Profile Domain,Private
```

Port 3000 (WhatsApp bridge) stays local only — do not open it.

For CCTV mode the server must reach the cameras on TCP 554:

```powershell
Test-NetConnection 192.168.1.100 -Port 554
```

---

## 15. Run as a Windows service (NSSM)

NSSM keeps the app running in the background, starts it at boot, and restarts it if it crashes.

### 15.1 Install NSSM

1. Download from https://nssm.cc/download (nssm 2.24).
2. Extract and copy `win64\nssm.exe` to `C:\nssm\nssm.exe`.

### 15.2 Create the service

```powershell
cd D:\attendance_web
mkdir logs
C:\nssm\nssm.exe install NizamAttendance "D:\attendance_web\venv\Scripts\python.exe" "D:\attendance_web\run.py"
C:\nssm\nssm.exe set NizamAttendance AppDirectory "D:\attendance_web"
C:\nssm\nssm.exe set NizamAttendance DisplayName "Nizam Energy AI Attendance"
C:\nssm\nssm.exe set NizamAttendance Description "AI face attendance web application"
C:\nssm\nssm.exe set NizamAttendance Start SERVICE_AUTO_START
C:\nssm\nssm.exe set NizamAttendance AppEnvironmentExtra USERPROFILE=D:\attendance_web\home PYTHONUNBUFFERED=1
C:\nssm\nssm.exe set NizamAttendance AppStdout "D:\attendance_web\logs\service_out.log"
C:\nssm\nssm.exe set NizamAttendance AppStderr "D:\attendance_web\logs\service_err.log"
C:\nssm\nssm.exe set NizamAttendance AppRotateFiles 1
C:\nssm\nssm.exe set NizamAttendance AppRotateBytes 10485760
C:\nssm\nssm.exe set NizamAttendance AppExit Default Restart
C:\nssm\nssm.exe set NizamAttendance AppRestartDelay 10000
C:\nssm\nssm.exe start NizamAttendance
```

`USERPROFILE=D:\attendance_web\home` makes the service use the model downloaded in step 9.

### 15.3 Check it

```powershell
Get-Service NizamAttendance
Get-Content D:\attendance_web\data\logs\attendance_system.log -Tail 30
```

Service control:

```powershell
Restart-Service NizamAttendance
Stop-Service NizamAttendance
Start-Service NizamAttendance
```

To change settings later: edit `.env`, then `Restart-Service NizamAttendance`.

Note: `CAMERA_MODE=browser` works fine as a service. Do not use a webcam attached to the server
itself in service mode — enrol and check in from client browsers instead.

---

## 16. WhatsApp bridge as a service

Your existing Node.js WhatsApp bridge (port 3000) must also run in the background.

1. Install Node.js LTS on the server and copy the bridge folder, e.g. `D:\whatsapp_bridge`.
2. Run it once manually and scan the QR code so the session is saved:

```powershell
cd D:\whatsapp_bridge
node index.js
```

3. Stop it (`Ctrl+C`) and register it as a service (replace `index.js` with your entry file):

```powershell
C:\nssm\nssm.exe install WhatsAppBridge "C:\Program Files\nodejs\node.exe" "D:\whatsapp_bridge\index.js"
C:\nssm\nssm.exe set WhatsAppBridge AppDirectory "D:\whatsapp_bridge"
C:\nssm\nssm.exe set WhatsAppBridge Start SERVICE_AUTO_START
C:\nssm\nssm.exe set WhatsAppBridge AppStdout "D:\whatsapp_bridge\bridge_out.log"
C:\nssm\nssm.exe set WhatsAppBridge AppStderr "D:\whatsapp_bridge\bridge_err.log"
C:\nssm\nssm.exe set WhatsAppBridge AppExit Default Restart
C:\nssm\nssm.exe set NizamAttendance DependOnService WhatsAppBridge
C:\nssm\nssm.exe start WhatsAppBridge
```

If the bridge uses a browser session (whatsapp-web.js), run the service under the same Windows account
used to scan the QR code: services.msc → WhatsAppBridge → Log On → This account.

---

## 17. Trust the certificate on kiosk devices (self-signed only)

Copy `D:\attendance_web\data\cert.pem` to each kiosk and rename it to `attendance.crt`.

Windows kiosk (as Administrator):

```powershell
Import-Certificate -FilePath C:\Temp\attendance.crt -CertStoreLocation Cert:\LocalMachine\Root
```

Android tablet: Settings → Security → Encryption & credentials → Install a certificate → CA certificate.

iPad: open the file → Settings → Profile Downloaded → Install, then Settings → General → About →
Certificate Trust Settings → enable it.

Domain-joined PCs: push it via Group Policy (Computer Configuration → Policies → Windows Settings →
Security Settings → Public Key Policies → Trusted Root Certification Authorities).

### Kiosk browser setup (Chrome/Edge)

1. Open `https://192.168.1.50:8000/kiosk`, allow the camera.
2. Select the correct camera in the dropdown (it is remembered).
3. Optional full-screen kiosk shortcut:

```
"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --kiosk https://192.168.1.50:8000/kiosk --edge-kiosk-type=fullscreen
```

Put the shortcut in `shell:startup` so it opens when the kiosk PC logs in.

---

## 18. Daily backup

Everything important is in `D:\attendance_web\data` (database, face photos, logs) plus `.env`.

Create `D:\attendance_web\backup.bat`:

```bat
@echo off
for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyy-MM-dd"') do set TODAY=%%i
set DST=E:\Backups\attendance\%TODAY%
robocopy "D:\attendance_web\data" "%DST%\data" /E /R:2 /W:5 /NFL /NDL /NP
copy /Y "D:\attendance_web\.env" "%DST%\.env"
forfiles /p "E:\Backups\attendance" /d -30 /c "cmd /c if @isdir==TRUE rd /s /q @path" 2>nul
```

Schedule it daily at 23:30:

```powershell
schtasks /Create /TN "Attendance Backup" /TR "D:\attendance_web\backup.bat" /SC DAILY /ST 23:30 /RU SYSTEM
```

Restore: stop the service, copy the backed-up `data` folder back to `D:\attendance_web\data`, start the service.

---

## 19. Updating the application

```powershell
Stop-Service NizamAttendance
robocopy "D:\attendance_web" "E:\Backups\attendance_code_before_update" /E /XD venv home
```

Copy the new `app\`, `static\`, `tools\` and `run.py` over the old ones. Do NOT overwrite `data\`, `home\`, `venv\` or `.env`.

```powershell
Start-Service NizamAttendance
Get-Content D:\attendance_web\data\logs\attendance_system.log -Tail 30
```

---

## 20. Verification checklist

| Check | How | Expected |
|---|---|---|
| GPU visible | `nvidia-smi` | GPU listed, CUDA 12.x |
| GPU used by app | `.\venv\Scripts\python check_gpu.py` | `GPU OK` |
| Service running | `Get-Service NizamAttendance` | `Running` |
| Health | `curl.exe -k https://localhost:8000/healthz` (or `http://` if no SSL) | `{"ok":true,...}` |
| Admin panel | `https://192.168.1.50:8000/` | Login prompt → Dashboard |
| AI engine | Dashboard card | `GPU (CUDA)` |
| Kiosk camera | Kiosk PC → `/kiosk` | Live video, green box on enrolled face |
| Check-in | Stand in front of kiosk in CHECK-IN mode | "Welcome NAME - checked in" |
| WhatsApp | Employee with number checks in | Message received |
| Email | Reports tab → "Email now" | Report email received |
| Reboot | Restart server | Both services start automatically |

Note: `/healthz` exists only in the latest code. If missing, open `/kiosk` instead.

---

## 21. Troubleshooting

### AI engine shows CPU

```powershell
cd D:\attendance_web
.\venv\Scripts\activate
pip list | findstr onnxruntime
```

- Both `onnxruntime` and `onnxruntime-gpu` listed → `pip uninstall -y onnxruntime onnxruntime-gpu` then `pip install "onnxruntime-gpu[cuda,cudnn]"`.
- `nvidia-smi` shows CUDA below 12 → update the NVIDIA driver.
- Error mentioning `cudnn64_9.dll` or `cublasLt64_12.dll` → reinstall with the `[cuda,cudnn]` extra and install the VC++ Redistributable.
- Service is CPU but manual run is GPU → the service account cannot see the GPU; set Log On to the Administrator account in services.msc.

### insightface install fails

Install "Desktop development with C++" (step 4), open a new terminal, and run
`pip install "numpy<2.0" cython` before `pip install insightface==0.7.3`. Use Python 3.11.

### Service starts then stops

```powershell
Get-Content D:\attendance_web\logs\service_err.log -Tail 50
```

Common causes: wrong path in NSSM, `.env` typo, port 8000 already used
(`netstat -ano | findstr :8000`), model missing in `D:\attendance_web\home\.insightface`.

### Camera blocked on the kiosk

The page must be opened over `https://` (step 13). The certificate must be trusted (step 17).
In the browser address bar → site permissions → Camera → Allow.

### Model download fails (proxy / no internet)

Download `buffalo_l.zip` manually and extract it as described in step 9.

### Wrong person / not recognized

- Wrong person matched → lower `MATCH_THRESHOLD` to 0.38 in `.env` and restart.
- Not recognized → raise to 0.45, or enrol 6 more photos in the kiosk lighting.

### Email not sent

Use a Gmail App Password; the server must reach `smtp.gmail.com:465`:

```powershell
Test-NetConnection smtp.gmail.com -Port 465
```

### WhatsApp errors in log

`Get-Service WhatsAppBridge` must be Running and `http://localhost:3000` reachable on the server.

### Logs

| Log | Path |
|---|---|
| Application | `D:\attendance_web\data\logs\attendance_system.log` |
| Service stdout/stderr | `D:\attendance_web\logs\service_out.log`, `service_err.log` |
| WhatsApp bridge | `D:\whatsapp_bridge\bridge_err.log` |

---

## 22. Quick command reference

| Task | Command |
|---|---|
| Restart app | `Restart-Service NizamAttendance` |
| Live log | `Get-Content D:\attendance_web\data\logs\attendance_system.log -Wait -Tail 20` |
| GPU usage | `nvidia-smi -l 2` |
| GPU check | `D:\attendance_web\venv\Scripts\python D:\attendance_web\check_gpu.py` |
| Remove service | `C:\nssm\nssm.exe remove NizamAttendance confirm` |
| Edit service | `C:\nssm\nssm.exe edit NizamAttendance` |
| Manual backup | `D:\attendance_web\backup.bat` |
